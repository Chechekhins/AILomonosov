import warnings
warnings.simplefilter('ignore')

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader, Subset
from scparadise.scnoah import get_frac
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.utils.class_weight import compute_class_weight
import pandas as pd
import numpy as np
import scanpy as sc
import gzip
import re
import scipy.sparse as sp
from scipy.sparse import issparse
from scipy.optimize import nnls
import anndata
import pickle
import mudata
import math
import copy
from tqdm import tqdm
import random
import networkx as nx
import gseapy as gp
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import seaborn as sns
from scipy.stats import fisher_exact, mannwhitneyu
from matplotlib_venn import venn2, venn2_circles

class scRNADataset(Dataset):
    '''
    Create dataset for scMoses model training.

    Initialization parameters
    -------------------------
    adata_or_mdata: AnnData or MuData object.
    use_hvg: bool (default: True)
        Whether to use highly variable genes for training.
    use_hvg: bool (default: True)
        Whether to use highly variable genes for training.
    feature_list: list (default: None)
        Whether to use list of features for training.
    batch_key: str (default: None)
        The key in adata.obs that indicates batch identifiers for batch correction (e.g. 'sample').
    covariate_keys: str (default: None) 
        List of keys in adata_or_mdata.obs used as covariates for conditioning the model.
    celltype_key: str (default: None)
        Key in adata_or_mdata.obs containing cell type labels, used for classification tasks.

    Returns
    -------
    Dataset for scMoses model training.
    
    '''
    def __init__(self, adata_or_mdata, use_hvg, feature_list, batch_key, covariate_keys=None, celltype_key=None):
        self.cell_to_modality_idx = None
        if hasattr(adata_or_mdata, "mod"):  # MuData
            self.modalities_keys = list(adata_or_mdata.mod.keys())
            self.X_mods = {}
            self.modality_slices = {}
            current_dim = 0
            for mod in self.modalities_keys:
                ad = adata_or_mdata.mod[mod]
                if feature_list is not None:
                    if feature_list[0] in ad.var_names:
                        ad = ad[:, feature_list]
                elif use_hvg and 'highly_variable' in ad.var:
                    ad = ad[:, ad.var.highly_variable]             
                X = ad.X.toarray() if hasattr(ad.X, 'toarray') else ad.X
                if X.min(0).any():
                    X = np.maximum(X, 0)
                    X_norm = (X - X.min(0)) / (np.ptp(X, axis=0) + 1e-10)
                else:
                    X_norm = (X - X.min(0)) / (np.ptp(X, axis=0) + 1e-10)
                tensor = torch.FloatTensor(X_norm)
                self.X_mods[mod] = tensor
                dim = tensor.size(1)
                self.modality_slices[mod] = slice(current_dim, current_dim + dim)
                current_dim += dim
            self.n_vars = sum(tensor.size(1) for tensor in self.X_mods.values())
            self.var_names = []
            for mod in self.modalities_keys:
                names = adata_or_mdata.mod[mod].var_names.tolist()
                if use_hvg and 'highly_variable' in adata_or_mdata.mod[mod].var:
                    names = [n for n, hv in zip(names, adata_or_mdata.mod[mod].var.highly_variable) if hv]
                self.var_names.extend([f"{mod}:{n}" for n in names])
            obs = adata_or_mdata.obs
            self.cell_names = list(obs.index)
            self.cell_to_modality_idx = {}
            for mod in self.modalities_keys:
                ad = adata_or_mdata.mod[mod]
                ad_names = list(ad.obs_names)
                name_to_idx = {name: i for i, name in enumerate(ad_names)}
                self.cell_to_modality_idx[mod] = [name_to_idx.get(cell, None) for cell in self.cell_names]
                
        else:  # AnnData
            ad = adata_or_mdata
            self.modalities_keys = ['rna']
            if feature_list is not None:
                if feature_list[0] in ad.var_names:
                    ad = ad[:, feature_list]
            elif use_hvg and 'highly_variable' in ad.var:
                ad = ad[:, ad.var.highly_variable]
            if ad.isbacked:
                ad = ad.to_memory()
            X = ad.X.toarray() if hasattr(ad.X, 'toarray') else ad.X
            if X.min(0).any():
                X = np.maximum(X, 0)
                X_norm = (X - X.min(0)) / (np.ptp(X, axis=0) + 1e-10)
            else:
                X_norm = (X - X.min(0)) / (np.ptp(X, axis=0) + 1e-10)
            tensor = torch.FloatTensor(X_norm)
            self.X_mods = {'rna': tensor}
            self.n_vars = tensor.size(1)
            self.modality_slices = {'rna': slice(0, self.n_vars)}
            self.var_names = ad.var_names.tolist()
            obs = ad.obs
            self.cell_names = list(obs.index)
            self.cell_to_modality_idx = {}
            for mod in self.modalities_keys:
                ad_names = list(ad.obs_names)
                name_to_idx = {name: i for i, name in enumerate(ad_names)}
                self.cell_to_modality_idx[mod] = [name_to_idx.get(cell, None) for cell in self.cell_names]

        # Check for NaN/Inf
        for t in self.X_mods.values():
            assert not torch.isnan(t).any(), "NaN in data!"
            assert not torch.isinf(t).any(), "Inf in data!"

        # Batch processing
        if batch_key is not None and batch_key in obs:
            self.batch_encoder = LabelEncoder()
            self.batch_labels = torch.LongTensor(
                self.batch_encoder.fit_transform(obs[batch_key])
            )
            self.n_batches = len(self.batch_encoder.classes_)
        else:
            self.batch_labels = torch.zeros(len(next(iter(self.X_mods.values()))), dtype=torch.long)
            self.n_batches = 1

        # Covariates
        self.covariates, self.covariate_info = self._process_covariates(obs, covariate_keys)

        # Cell type labels
        if celltype_key is not None and celltype_key in obs:
            self.label_encoder = LabelEncoder()
            self.celltype_labels = torch.LongTensor(
                self.label_encoder.fit_transform(obs[celltype_key])
            )
            self.n_celltypes = len(self.label_encoder.classes_)
        else:
            self.celltype_labels = None
            self.n_celltypes = None

    def _process_covariates(self, obs, covariate_keys):
        if not covariate_keys:
            return torch.zeros((len(next(iter(self.X_mods.values()))), 0)), {}
        cov_list, info = [], {}
        current_dim = 0
        for key in covariate_keys:
            col = obs[key]
            if col.dtype.name in ['category', 'object']:
                enc = LabelEncoder()
                e = enc.fit_transform(col)
                tensor = F.one_hot(torch.LongTensor(e), num_classes=len(enc.classes_)).float()
                cov_list.append(tensor)
                info[key] = {'type': 'categorical', 'start_dim': current_dim,
                             'end_dim': current_dim + tensor.size(1),
                             'n_classes': tensor.size(1), 'encoder': enc}
                current_dim += tensor.size(1)
            else:
                arr = col.values.reshape(-1, 1)
                if len(np.unique(arr)) == 1:
                    scaled = np.zeros_like(arr)
                    scaler = None
                else:
                    scaler = StandardScaler()
                    scaled = scaler.fit_transform(arr)
                tensor = torch.FloatTensor(np.nan_to_num(scaled))
                cov_list.append(tensor)
                info[key] = {'type': 'continuous', 'start_dim': current_dim,
                             'end_dim': current_dim + 1, 'scaler': scaler}
                current_dim += 1
        covs = torch.cat(cov_list, dim=1)
        covs = torch.nan_to_num(covs, nan=0.0)
        return covs, info

    def __len__(self):
        return len(next(iter(self.X_mods.values())))

    def __getitem__(self, idx):
        x_mods = {}
        for mod in self.modalities_keys:
            local_idx = self.cell_to_modality_idx[mod][idx]
            if local_idx is None:
                x_mods[mod] = torch.zeros(self.X_mods[mod][0].shape, dtype=self.X_mods[mod].dtype)
            else:
                x_mods[mod] = self.X_mods[mod][local_idx]
        cov = self.covariates[idx] if self.covariates.size(1) > 0 else torch.zeros(0)
        batch = self.batch_labels[idx]
        if self.celltype_labels is not None:
            label = self.celltype_labels[idx]
            return x_mods, cov, batch, idx, label
        else:
            return x_mods, cov, batch, idx

# Function to compute covariate complexity weights
def compute_covariate_complexity_weights(covariates, covariate_info):
    if covariates.size(1) == 0:
        return torch.ones(0, device=covariates.device)
    
    device = covariates.device
    cov_dim = covariates.size(1)
    complexity_scores = []
    
    for cov_name, info in covariate_info.items():
        start_dim = info['start_dim']
        end_dim = info['end_dim']
        cov_slice = covariates[:, start_dim:end_dim]
        
        if info['type'] == 'categorical':
            n_classes = info['n_classes']
            
            # Calculate empirical distribution
            probs = cov_slice.mean(dim=0) + 1e-10  # One-hot encoded probabilities
            probs = probs / probs.sum()
            # Entropy: -sum(p * log(p))
            entropy = -(probs * torch.log(probs + 1e-10)).sum().item()
            max_entropy = np.log(n_classes) if n_classes > 1 else 1e-10
            normalized_entropy = entropy / max_entropy if max_entropy > 0 else 0.0
            # Cardinality complexity: more categories = more complex
            cardinality_score = min(n_classes / 10.0, 1.0)  # Cap at 10 categories
            # Combined complexity score
            complexity = 0.6 * normalized_entropy + 0.4 * cardinality_score
            
            # Assign same complexity to all one-hot dimensions
            for _ in range(end_dim - start_dim):
                complexity_scores.append(complexity)
        
        else:
            var = torch.var(cov_slice, dim=0, unbiased=False).item()            
            # Non-uniformity measure (deviation from uniform distribution)
            sorted_vals, _ = torch.sort(cov_slice.squeeze())
            uniform_spacing = 1.0 / (len(sorted_vals) - 1) if len(sorted_vals) > 1 else 0
            actual_spacings = torch.diff(sorted_vals)
            if len(actual_spacings) > 0:
                spacing_var = torch.var(actual_spacings).item()
                non_uniformity = min(spacing_var / (uniform_spacing + 1e-8), 1.0)
            else:
                non_uniformity = 0.0
            
            # Combine variance and non-uniformity
            complexity = 0.7 * min(var, 1.0) + 0.3 * non_uniformity
            complexity_scores.append(complexity)
    
    # Convert to tensor
    complexity_tensor = torch.tensor(complexity_scores, device=device, dtype=torch.float32)
    
    # Normalize to [0, 1]
    if complexity_tensor.max() > complexity_tensor.min():
        normalized_complexity = (complexity_tensor - complexity_tensor.min()) / (complexity_tensor.max() - complexity_tensor.min() + 1e-8)
    else:
        normalized_complexity = torch.ones_like(complexity_tensor) * 0.5
    weights = 0.3 + 1.2 * torch.sigmoid(5.0 * (normalized_complexity - 0.5))
    
    return weights

# CovariateConditioner for covariates
class CovariateConditioner(nn.Module):
    def __init__(self, cov_dim, latent_dim):
        super().__init__()
        if cov_dim > 0:
            self.projection = nn.Sequential(
                nn.Linear(cov_dim, latent_dim // 2),
                nn.LayerNorm(latent_dim // 2),
                nn.GELU(),
                nn.Dropout(0.1),
                nn.Linear(latent_dim // 2, latent_dim // 4)
            )
            
            # Initialize for stability
            for layer in self.projection:
                if isinstance(layer, nn.Linear):
                    nn.init.xavier_normal_(layer.weight, gain=0.01)
                    nn.init.zeros_(layer.bias)
        else:
            self.projection = None
        
        # Store pre-computed complexity weights
        self.register_buffer('complexity_weights', None)
    
    def set_complexity_weights(self, weights):
        self.complexity_weights = weights
    
    def forward(self, cov):
        if self.projection is None or cov.size(1) == 0:
            return None
        
        # Apply complexity-based weighting to covariates
        if self.complexity_weights is not None:
            weighted_cov = cov * self.complexity_weights.unsqueeze(0)  # (batch_size, cov_dim)
        else:
            weighted_cov = cov
        
        return self.projection(weighted_cov)
        
class AdaptiveLossBalancer(nn.Module):
    def __init__(self, num_losses):
        super().__init__()
        self.weights = nn.Parameter(torch.ones(num_losses))
    def forward(self, losses):
        return torch.sum(torch.stack(losses) * torch.softmax(self.weights, dim=0))

class LatentAttention(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.attn = nn.Linear(dim, 1)
    def forward(self, x):
        w = torch.sigmoid(self.attn(x))
        return x * w

# To solve degradation problem
class ResidualBlock(nn.Module):
    def __init__(self, hidden_dim, dropout):
        super().__init__()
        self.block = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, hidden_dim)
        )
    def forward(self, x):
        return x + self.block(x)

class GradientReversal(nn.Module):
    def forward(self, x):
        return x
    def backward(self, grad_output):
        return -grad_output

# Combiner for latent spaces of different modalities
class LatentCombiner(nn.Module):
    """
    Diffusion-Inspired GNN.
    Combines latent spaces of differend modalities.
    """
    def __init__(self, latent_dim):
        super().__init__()
        self.latent_dim = latent_dim
        self.affine = nn.Linear(latent_dim, latent_dim, bias=False)
        self.final_proj = nn.Sequential(
            nn.LayerNorm(latent_dim),
            nn.GELU(),
            nn.Linear(latent_dim, latent_dim)
        )
        nn.init.xavier_uniform_(self.affine.weight)

    def forward(self, mu_list):
        if len(mu_list) == 1:
            return self.final_proj(mu_list[0])

        H0 = torch.stack(mu_list, dim=1)

        # Attention weights 
        A = F.relu(torch.matmul(H0, H0.transpose(1, 2)))
        A = A + 1e-6                                    
        D_inv = 1 / A.sum(-1, keepdim=True)               
        H1 = torch.matmul(D_inv * A, H0)                  
        H1 = self.affine(H1)                       
        combined = H1.mean(1)
        return self.final_proj(combined)

class mosesVAE(nn.Module):
    '''
    scMoses model.
    Creates scMoses model with modality-specific encoders and decoders. 
    Uses batch_key, covariates and celltype_key if given.
    '''
    def __init__(
        self, 
        input_dims, 
        n_batches, 
        random_state, 
        latent_dim, 
        cov_dim=0, 
        hidden_dim=256, 
        dropout=0.1,
        dropout_classifier=0.2,
        n_celltypes=None, 
        modalities_keys=None,
        cat_dict=None,
        covariate_info=None
    ):
        super().__init__()
        self.n_batches = n_batches
        self.input_dims = input_dims
        self.cov_dim = cov_dim
        self.hidden_dim = hidden_dim
        self.dropout = dropout
        self.dropout_classifier = dropout_classifier
        self.latent_dim = latent_dim
        self.n_celltypes = n_celltypes
        self.modalities_keys = modalities_keys or []
        self.n_modalities = len(self.modalities_keys)
        self.cat_dict = cat_dict
        self.covariate_info = covariate_info

        # Random state fixation
        np.random.seed(random_state)
        torch.manual_seed(random_state)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(random_state)
            torch.backends.cudnn.deterministic = True
            torch.backends.cudnn.benchmark = False

        # Celltype classifier to use celltype_key in scMoses model training 
        if n_celltypes is not None:
            self.celltype_classifier = nn.Sequential(
                LatentAttention(latent_dim),
                nn.Linear(latent_dim, hidden_dim),
                nn.LayerNorm(hidden_dim),
                nn.GELU(),
                nn.Dropout(dropout_classifier),
                nn.Linear(hidden_dim, n_celltypes)
            )
        else:
            self.celltype_classifier = None

        # Covariate conditioning
        self.cov_conditioner = CovariateConditioner(cov_dim=self.cov_dim, latent_dim=self.latent_dim) if self.cov_dim > 0 else None

        # Modality specific Encoders and Decoders
        self.encoders = nn.ModuleDict()
        self.decoders = nn.ModuleDict()
        for mod in self.modalities_keys:
            # Encoder input
            enc_in = input_dims[mod] + n_batches + (latent_dim // 4 if cov_dim > 0 else 0)
            # Encoders
            self.encoders[mod] = nn.Sequential(
                nn.Linear(enc_in, hidden_dim),
                nn.LayerNorm(hidden_dim),
                nn.GELU(),
                ResidualBlock(hidden_dim, dropout),
                nn.Linear(hidden_dim, latent_dim * 2)
            )
            # Decoder input
            dec_in = latent_dim + n_batches + (latent_dim // 4 if cov_dim > 0 else 0)
            # Decoders
            self.decoders[mod] = nn.Sequential(
                nn.Linear(dec_in, hidden_dim),
                nn.LayerNorm(hidden_dim),
                nn.GELU(),
                ResidualBlock(hidden_dim, dropout),
                nn.Linear(hidden_dim, input_dims[mod]),
                nn.Sigmoid()
            )

        # NN to combine latent spaces
        if self.n_modalities > 1:
            self.latent_combiner = LatentCombiner(latent_dim)
        else:
            self.latent_combiner = False
        
        # Discriminator for batch correction
        self.discriminator = nn.Sequential(
            GradientReversal(),
            nn.Linear(latent_dim, hidden_dim // 2),
            nn.LeakyReLU(0.2),
            nn.Linear(hidden_dim // 2, n_batches)
        )

    # Encode for creation of latent space
    def encode(self, x_mods, cov, batch_onehot):
        mu_mods, logvar_mods = [], []
        valid_modalities = []
        for mod in self.modalities_keys:
            x = x_mods[mod]
            inputs = [x, batch_onehot]
            if self.cov_conditioner:
                cond = self.cov_conditioner(cov)
                if cond is not None:
                    inputs.append(cond)
            h = torch.cat(inputs, dim=1)
            mu, logvar = self.encoders[mod](h).chunk(2, dim=-1)
            mu_mods.append(mu)
            logvar_mods.append(logvar)
            valid_modalities.append(mod)
        if len(mu_mods) > 1:    
            mu_combined = self.latent_combiner(mu_mods)
        else:
            mu_combined = mu_mods[0]
        logvar_combined = torch.mean(torch.stack(logvar_mods), dim=0)
        return mu_combined, logvar_combined, valid_modalities

    def reparameterize(self, mu, logvar):
        std = torch.exp(0.5 * logvar)
        return mu + std * torch.randn_like(std)

    # Decode latent space back into gene expression or other modality data
    def decode(self, z, cov, batch_onehot, valid_modalities=None):
        recon_x_mods = {}
        inputs = [z, batch_onehot]
        if self.cov_conditioner:
            cond = self.cov_conditioner(cov)
            if cond is not None:
                inputs.append(cond)
        h = torch.cat(inputs, dim=1)
        for mod in (valid_modalities if valid_modalities is not None else self.modalities_keys):
            recon_x_mods[mod] = self.decoders[mod](h)
        return recon_x_mods

    # Forward pass
    def forward(self, x, cov, batch_labels):
        batch_onehot = F.one_hot(batch_labels, self.n_batches).float().to(next(self.parameters()).device)
        mu, logvar, valid_modalities = self.encode(x, cov, batch_onehot)
        z = self.reparameterize(mu, logvar)
        celltype_pred = self.celltype_classifier(z) if self.celltype_classifier else None
        recon_x = self.decode(z, cov, batch_onehot, valid_modalities)
        domain_pred = self.discriminator(z)
        return recon_x, mu, logvar, z, domain_pred, celltype_pred, valid_modalities

    @property
    def genes(self):
        return getattr(self, '_genes', None)

    @genes.setter
    def genes(self, value):
        self._genes = value

    def set_encoders_from_dataset(self, dataset):
        if hasattr(dataset, 'batch_encoder'):
            self.batch_encoder = dataset.batch_encoder
        if hasattr(dataset, 'label_encoder'):
            self.label_encoder = dataset.label_encoder
        if hasattr(dataset, 'covariate_info'):
            self.covariate_info = dataset.covariate_info
        if hasattr(dataset, 'var_names'):
            self.var_names = dataset.var_names

    # Function for saving model
    def save_model(self, path):
        """
        Saves the model state, including VAE and any attached ensemble classifiers.
        """
        save_dict = {
            'state_dict': self.state_dict(),
            'input_dims': self.input_dims,
            'n_batches': self.n_batches,
            'cov_dim': self.cov_dim,
            'hidden_dim': self.hidden_dim,
            'dropout': self.dropout,
            'latent_dim': self.latent_dim,
            'random_state': getattr(self, 'random_state', 1),
            'n_celltypes': self.n_celltypes,
            'modalities_keys': self.modalities_keys,
            'kl_cap': self.kl_cap,
            'batch_key': getattr(self, 'batch_key', None),
            'var_names': getattr(self, 'var_names', None),
            'history': getattr(self, 'history', None),
            'best_epoch': getattr(self, 'best_epoch', None),
            'cat_dict': getattr(self, 'cat_dict', None)
        }
    
        # Save sklearn encoders using pickle
        if hasattr(self, 'batch_encoder'):
            save_dict['batch_encoder'] = pickle.dumps(self.batch_encoder)
        if hasattr(self, 'label_encoder'):
            save_dict['label_encoder'] = pickle.dumps(self.label_encoder)
        if hasattr(self, 'covariate_info'):
            save_dict['covariate_info'] = pickle.dumps(self.covariate_info)
    
        # Add attributes from train_ensemble_gpu if they exist
        if hasattr(self, 'celltype_classifiers'):
            save_dict['celltype_classifiers_states'] = [clf.state_dict() for clf in self.celltype_classifiers]
            save_dict['ensemble_input_dim'] = self.ensemble_input_dim
            save_dict['ensemble_hidden_dim'] = self.ensemble_hidden_dim
            save_dict['lst_genes'] = self.lst_genes
            save_dict['classifiers_histories'] = self.classifiers_histories
            save_dict['celltype_key'] = self.celltype_key
    
        torch.save(save_dict, path)
        print(f"Model saved to: {path}")

    # Function for loading model
    @classmethod
    def load_model(cls, path, device='auto'):
        """
        Loads a model, intelligently handling the presence or absence of a celltype classifier.

        Parameters
        ----------
        path: str, path object
            Path to a model file (e.g. model.pth)
        device: str, (default: 'auto')
            Type of device to load model ('cpu', 'cuda'). Set 'auto' for automatic selection.
        
        """
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu') if device == 'auto' else device
        chk = torch.load(path, map_location=device)
    
        random_state = chk.get('random_state', 1)
        
        # Determine if a classifier was saved
        if 'celltype_classifiers_states' in chk.keys():
            has_classifier = True
        else:
            has_classifier = False
            
    
        model = cls(
            input_dims=chk['input_dims'],
            n_batches=chk['n_batches'],
            random_state=random_state,
            latent_dim=chk['latent_dim'],
            cov_dim=chk.get('cov_dim', 0),
            hidden_dim=chk.get('hidden_dim', 256),
            dropout=chk.get('dropout', 0.1),
            n_celltypes=chk.get('n_celltypes') if has_classifier else None,
            modalities_keys=chk.get('modalities_keys', None),
            cat_dict=chk.get('cat_dict', None)
        )
    
        # Load the state dict. `strict=False` allows loading a VAE-only model
        # into a VAE+Classifier architecture, ignoring the missing classifier keys.
        model.load_state_dict(chk['state_dict'], strict=False)
    
        # Restore metadata
        if 'batch_encoder' in chk:
            model.batch_encoder = pickle.loads(chk['batch_encoder'])
        if 'label_encoder' in chk and has_classifier:
            model.label_encoder = pickle.loads(chk['label_encoder'])
        if 'covariate_info' in chk:
            model.covariate_info = pickle.loads(chk['covariate_info'])
    
        for key in ['var_names', 'history', 'best_epoch', 'batch_key']:
            if key in chk:
                setattr(model, key, chk[key])
        
        # Logic to load the ensemble classifiers if they were saved separately
        if 'celltype_classifiers_states' in chk:
            print("Loading ensemble classifier...")
            input_dim = chk['ensemble_input_dim']
            hidden_dim = chk['ensemble_hidden_dim']
            n_classes = chk['n_celltypes']
    
            # Ensure MLP classes are available in the scope
            model_classes = [
                lambda: MLP1(input_dim, hidden_dim, n_classes),
                lambda: MLP2(input_dim, hidden_dim, n_classes),
                lambda: MLP3(input_dim, hidden_dim, n_classes)
            ]
            
            classifiers = []
            for i, model_fn in enumerate(model_classes):
                clf = model_fn().to(device)
                clf.load_state_dict(chk['celltype_classifiers_states'][i])
                clf.eval()
                classifiers.append(clf)
    
            model.celltype_classifiers = classifiers
            model.lst_genes = chk['lst_genes']
            model.classifiers_histories = chk['classifiers_histories']
            model.ensemble_input_dim = input_dim
            model.ensemble_hidden_dim = hidden_dim
            model.celltype_key = chk['celltype_key']
            model.kl_cap = chk['kl_cap']
    
        model.to(device)
        print(f"Model loaded from: {path}")
        return model

def move_dict_to_device(d, device):
    return {k: v.to(device) for k, v in d.items()}
    
# train_moses_vae function to train scMoses model
def train_moses_vae(
    model,
    train_loader,
    test_loader,
    optimizer_vae,
    optimizer_disc,
    noise_scale,
    device,
    epochs,
    patience,
    batch_key,
    cov_dim,
    warmup_epochs,
    celltype_settings,
    noise_probability,
    celltype_key = None,
    n_celltypes = None,
    class_weights = None,
    kl_scheduler = None,
    verbose = True
):
    """
    MosesVAE model training with support for unimodal/multimodal data and modality-specific encoders.
    """
    best_loss = float("inf")
    patience_count = 0

    # Create model history
    history = {
        'label_weight': [],
        'train_loss': [],
        'vae_loss': [],
        'adv_loss': [],
        'celltype_loss': [],
        'test_loss': [],
        'kl_weight': [],
        'recon_loss_per_modality': {mod: [] for mod in model.modalities_keys}
    }

    model = model.to(device)

    # Create loss balancers 
    n_losses = 3 + int(celltype_key is not None)
    loss_balancer = AdaptiveLossBalancer(n_losses).to(device) # Training loss balancer
    loss_balancer_val = AdaptiveLossBalancer(2).to(device) # Validation loss balancer

    total_steps = epochs * max(1, len(train_loader))
    warmup_steps = int(0.05 * total_steps)
    
    global_step = 0
    
    def vae_lr_lambda(step):
        if step < warmup_steps:
            return max(step / max(1, warmup_steps), 1e-3)
        progress = (step - warmup_steps) / max(1, total_steps - warmup_steps)
        return 0.3 + 0.7 * (1 - progress) ** 0.5  # sqrt decay вместо cosine
    
    def disc_lr_lambda(step):
        if step < warmup_steps:
            return max(0.5 * step / max(1, warmup_steps), 5e-4)
        return 1.0
    
    scheduler_vae = torch.optim.lr_scheduler.LambdaLR(optimizer_vae, vae_lr_lambda)
    scheduler_disc = torch.optim.lr_scheduler.LambdaLR(optimizer_disc, disc_lr_lambda)
    
    # Train model
    for epoch in tqdm(range(epochs), desc='Training scMoses model', colour='green', disable = not verbose):
        best_model = copy.deepcopy(model)
        model.train()
        total_train_loss = 0.0
        total_vae_loss = 0.0
        total_adv_loss = 0.0
        total_celltype_loss = 0.0

        current_noise = noise_scale * (epoch / epochs)
        
        # Train loop
        for batch in train_loader:
            if len(batch) == 5:
                x_mods, cov, batch_labels, _, labels = batch
            else:
                x_mods, cov, batch_labels, _ = batch
                labels = None

            # Moving a dictionary of tensors to the device
            x_mods = move_dict_to_device(x_mods, device)
            cov = cov.to(device) if cov.size(1) > 0 else torch.zeros(x_mods[list(x_mods.keys())[0]].size(0), 0, device=device)
            batch_labels = batch_labels.to(device)

            #if current_noise > 0:
            #    x_mods = {mod: torch.clamp(x + torch.randn_like(x) * current_noise, 0, 1) for mod, x in x_mods.items()}

            x_mods_clean = {mod: x.clone() for mod, x in x_mods.items()}
            if noise_scale > 0 and torch.rand(1).item() < noise_probability:
                x_mods = {mod: torch.clamp(x + torch.randn_like(x) * noise_scale, 0, 1) for mod, x in x_mods.items()}

            # Forward pass
            recon_x, mu, logvar, z, domain_pred, celltype_pred, valid_modalities = model.forward(
                x_mods, cov, batch_labels
            )

            # Reconstruction loss
            recon_loss = 0.0
            for mod in valid_modalities:
                if x_mods[mod] is not None:
                    recon_loss_mod = F.binary_cross_entropy(recon_x[mod], x_mods_clean[mod], reduction='sum')
                    recon_loss += recon_loss_mod
            recon_loss_norm = recon_loss / len(train_loader.dataset)
            
            # Kl loss
            kl_weight = kl_scheduler.value(global_step)
            kl_loss = -kl_weight * torch.sum(1 + logvar - mu.pow(2) - logvar.exp())
            kl_loss_norm = kl_loss / len(train_loader.dataset)
            history['kl_weight'].append(float(kl_weight))
            global_step += 1

            # Adversarial loss
            if batch_key is not None:
                adv_loss = F.cross_entropy(domain_pred, batch_labels)
                adv_loss_norm = adv_loss / len(train_loader.dataset)
            else:
                adv_loss_norm = torch.tensor(0.0, device=device)

            # Cell type loss
            if celltype_key is not None and model.celltype_classifier is not None:
                labels = labels.to(device) if labels is not None else None
                mask = labels >= 0 if labels is not None else torch.ones(z.size(0), dtype=torch.bool, device=device)
                celltype_pred = model.celltype_classifier(z)
                cell_loss = F.cross_entropy(celltype_pred[mask], labels[mask], weight=class_weights)
                if celltype_settings[0] == 'soft':
                    t =  epoch / max(epoch, 150)
                    label_weight = celltype_settings[1] * (1.0 / (1.0 + math.exp(-10 * (t - 0.5))))
                    label_weight = min([label_weight, celltype_settings[1]])
                elif celltype_settings[0] == 'hard':
                    label_weight = 1 + (2000 * (epoch / epochs))
                    label_weight = min([label_weight, celltype_settings[1]])
                else:
                    assert ValueError('Mode of celltype weightening should be `hard` or `soft`')
                celltype_loss_norm = label_weight * cell_loss / len(train_loader.dataset)
            else:
                celltype_loss_norm = torch.tensor(0.0, device=device)

            # Combine losses
            losses = [recon_loss_norm, kl_loss_norm, adv_loss_norm]
            if celltype_key is not None:
                losses.append(celltype_loss_norm)
            # Balance losses 
            total_loss = loss_balancer(losses)

            optimizer_vae.zero_grad()
            optimizer_disc.zero_grad()
            total_loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            optimizer_vae.step()
            optimizer_disc.step()

            total_train_loss += total_loss.item()
            total_vae_loss += (recon_loss_norm.item() + kl_loss_norm.item())
            total_adv_loss += adv_loss_norm.item()
            total_celltype_loss += celltype_loss_norm.item()

            scheduler_vae.step()
            scheduler_disc.step()

        # Add elements to model history
        if celltype_key is not None:
            history['label_weight'].append(label_weight)
        n_batches = len(train_loader)
        history['train_loss'].append(total_train_loss / n_batches)
        history['vae_loss'].append(total_vae_loss / n_batches)
        history['adv_loss'].append(total_adv_loss / n_batches)
        history['celltype_loss'].append(total_celltype_loss / n_batches)

        # Validation loop
        model.eval()
        test_loss = 0.0
        with torch.no_grad():
            for batch in test_loader:
                if len(batch) == 5:
                    x_mods_val, cov_val, batch_val, _, _ = batch
                else:
                    x_mods_val, cov_val, batch_val, _ = batch
                x_mods_val = move_dict_to_device(x_mods_val, device)
                cov_val = cov_val.to(device) if cov_val.size(1) > 0 else torch.zeros(x_mods_val[list(x_mods_val.keys())[0]].size(0), 0, device=device)
                batch_val = batch_val.to(device)
                batch_onehot_val = F.one_hot(batch_val, model.n_batches).float().to(device)
                mu_val, logvar_val, _ = model.encode(x_mods_val, cov_val, batch_onehot_val)
                z_val = model.reparameterize(mu_val, logvar_val)
                recon_val = model.decode(z_val, cov_val, batch_onehot_val)

                # Reconstruction validation loss
                recon_loss_val = 0.0
                for mod in model.modalities_keys:
                    present_mask = (x_mods_val[mod].sum(dim=1) != 0)
                    if present_mask.any():
                        recon_loss_val += F.binary_cross_entropy(
                            recon_val[mod][present_mask], x_mods_val[mod][present_mask], reduction='sum'
                        )
                recon_loss_val_norm = recon_loss_val / len(batch)
                
                # Kl validation loss
                kl_loss_val = -kl_weight * torch.sum(1 + logvar_val - mu_val.pow(2) - logvar_val.exp())
                kl_loss_val_norm = kl_loss_val / len(batch)
                
                test_losses = [recon_loss_val_norm, kl_loss_val_norm]
                test_loss = loss_balancer_val(test_losses)

        history['test_loss'].append(test_loss)

        # Use patience for early stopping
        # Start patience count only after warmup_epochs
        if epoch > warmup_epochs:
            if history['test_loss'][-1] < best_loss:
                best_loss = history['test_loss'][-1]
                patience_count = 0
                best_model = copy.deepcopy(model)
                best_model.best_epoch = epoch
            else:
                patience_count += 1
                if patience_count >= patience:
                    print(f"Early stopping at epoch {epoch+1}")
                    break

    return history, best_model

def _interbatch_var_per_mod(dataset, mod, device='cpu'):
    """
    Calculates average variance between batches in modality mod.
    Accounts for incomplete modalities via cell_to_modality_idx.
    """
    mapping = dataset.cell_to_modality_idx.get(mod, None)
    if mapping is None:
        return None, 1.0 
    present = [i for i, j in enumerate(mapping) if j is not None]
    if len(present) == 0:
        return None, 1.0
    local_idx = [mapping[i] for i in present]
    X = dataset.X_mods[mod][local_idx].to(device)  
    batches = dataset.batch_labels[present].to(device) 
    uniq = torch.unique(batches)
    if uniq.numel() < 2:
        return 0.0, 1.0
    means = []
    for b in uniq:
        mask = (batches == b)
        if mask.any():
            means.append(X[mask].mean(dim=0))
    if len(means) < 2:
        return 0.0, len(present) / len(dataset)
    M = torch.stack(means, dim=0)  # [n_batches_mod, n_feat]
    inter_var = M.var(dim=0, unbiased=False).mean().item()
    coverage = len(present) / len(dataset)
    return inter_var, coverage

def estimate_kl_cap(
    dataset,
    min_kl=0.005,
    max_kl=0.2,
    v_min=5e-4, v_max=5e-3,
    device='cpu'
):
    """
    Estimation of the Kl regularization weight for the dataset.
    """
    vars_norm, coverages = [], []
    for mod in dataset.modalities_keys:
        v, cov = _interbatch_var_per_mod(dataset, mod, device=device)
        if v is None:
            continue
        x = (float(v) - v_min) / (v_max - v_min)
        vars_norm.append(np.clip(x, 0., 1.))
        coverages.append(cov)

    complexity = 0.
    if vars_norm:
        w = np.asarray(coverages) / (np.sum(coverages) + 1e-10)
        complexity = float(np.dot(vars_norm, w))          # 0‥1
    base_cap = min_kl + (max_kl - min_kl) * (1. - complexity)**2

    N = len(dataset)
    if (N > 50000) and (complexity > 0.5):
        size_scale = 1. - complexity 
    elif (N > 30000) and complexity > 0.5:
        size_scale = 1. + complexity
    elif complexity > 0.5:
        size_scale = 1. + 4 * complexity
    else:
        size_scale = 1. + 0.15 * complexity
    cap = float(np.clip(base_cap * size_scale, min_kl, max_kl))
    return cap, dict(complexity=complexity, cap=cap, n_cells=N)

class KL_Scheduler:
    """
    Step scheme:
    """
    def __init__(self, kl_cap, total_steps):
        self.kl_cap = float(kl_cap)
        self.warmup_steps = int(total_steps * 0.01)
        self.ramp_steps   = int(total_steps * 0.1)
        self.total_steps  = total_steps

    def value(self, step):
        if step < self.warmup_steps:
            return 0.0
        elif step < self.warmup_steps + self.ramp_steps:
            s = (step - self.warmup_steps) / max(1, self.ramp_steps)
            return self.kl_cap * s
        else:
            return self.kl_cap

# Integration function
def train(
    adata_or_mdata, 
    latent_key = 'scMoses', 
    batch_key = None, 
    celltype_key = None,
    celltype_settings = [100, 'soft'],
    test_size = 0.1, 
    noise_scale = 0.001,
    noise_probability = 0.5,
    covariate_keys = None, 
    hidden_dim = 256, 
    dropout=0.1,
    dropout_classifier=0.2,
    latent_dim = 20, 
    patience = 10,
    batch_size = 128, 
    epochs = 500, 
    warmup_epochs = 'auto',
    device = 'auto', 
    use_hvg = False,
    feature_list = None,
    random_state = 1, 
    verbose = True
):
    '''
    Train scMoses model for unimodal/multimodal (including partially overlapping) data integration. 

    Parameters
    ----------
    adata_or_mdata: AnnData or MuData object.
    batch_key: str (default: None)
        The key in adata.obs that indicates batch identifiers for batch correction (e.g. 'sample').
    latent_key: str (default: 'X_scMoses')
        The key specifying where to store the latent representation in the adata_or_mdata.obsm.
    test_size: float (default: 0.1) 
        Fraction of the dataset to reserve as a test data during training.
    noise_scale: float (default: 0.001)
        Scale of noise added during training for regularization.
    noise_probability: float (default: 0.5)
        The probability of applying noise to a batch.
    covariate_keys: str (default: None) 
        List of keys in adata_or_mdata.obs used as covariates for conditioning the model.
    hidden_dim: int (default: 256)
        Dimension of hidden layers in the scMoses model.
    dropout: float (default: 0.1)
        Portion of neurons in scMoses model that temporarily ignored during training (prevents overfitting).
    dropout_classifier: float (default: 0.2)
        Portion of neurons in scMoses classifier (works if celltype_key is not None) 
        that temporarily ignored during training (prevents classifier overfitting).
    latent_dim: int (default: 20)
        Dimension of the latent space learned by the scMoses model.
    random_state: int (default: 1)
        Seed for random number generators to ensure reproducibility.
    patience: int (default: 10)
        Number of consecutive epochs without improvement before performing early stopping.
    batch_size: int (default: 128)
        Number of samples per batch during training.
    epochs: int (default: 500)
        Maximum number of training epochs.
    warmup_epochs: int (default: 'auto')
        Number of epochs for warm-up of KL divergence weight.
    device: str (default: 'auto')
        Type of device to use for model training ('cpu' or 'cuda'). Set to 'auto' for automatic selection.
    use_hvg: bool (default: False)
        Whether to use highly variable genes for training.
    feature_list: list (default: None)
        Whether to use list of features for training.
    celltype_key: str (default: None)
        Key in adata_or_mdata.obs containing cell type labels, used for classification tasks.
    celltype_settings: list (default: ['soft', 100])
        Settings related to celltype weighting during training; you need to specify mode and weight.
        Two modes are available: 
        1) 'soft' mode — soft influence of cell type on the formation of the scMoses latent space (recommended weight: 100). 
        2) 'hard' mode — hard influence of cell type on the formation of the scMoses latent space (recommended weight: 1000).

    Returns
    -------
    Trained scMoses model and adds the latent space to adata_or_mdata.obsm.

    Example
    --------
    
    .. plot::
    
        # scMoses model training on a single dataset
        model = scparadise.scmoses.train(
            adata_or_mdata,
            latent_key = 'scMoses'
        )
        
        # scMoses model training with batch (and covariate) correction
        model = scparadise.scmoses.train(
            adata_or_mdata,
            latent_key = 'scMoses',
            batch_key = 'sample', 
            covariate_keys = ['sex', 'age'], # optional
            celltype_key = 'celltype' # optional
        )
        
    '''
    np.random.seed(random_state)
    torch.manual_seed(random_state)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(random_state)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
        
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu') if device=='auto' else device

    # Prepare dataset for training
    dataset = scRNADataset(adata_or_mdata, use_hvg, feature_list, batch_key, covariate_keys, celltype_key)
    cov_dim = dataset.covariates.size(1) if covariate_keys else 0

    # Train/test split
    inds = np.arange(len(dataset))
    if batch_key is not None:
        train_idx, test_idx = train_test_split(
            inds, 
            test_size = test_size,          
            stratify = adata_or_mdata.obs[batch_key], 
            random_state = random_state
        )
    else:
        train_idx, test_idx = train_test_split(
            inds, 
            test_size = test_size,
            stratify = None, 
            random_state = random_state
        )

    train_loader = DataLoader(Subset(dataset, train_idx), batch_size=batch_size, shuffle=True)
    test_loader = DataLoader(Subset(dataset, test_idx), batch_size=batch_size, shuffle=False)

    # Preparing a dictionary of dimensions for each modality
    input_dims = {mod: dataset.X_mods[mod].size(1) for mod in dataset.modalities_keys}

    # Create covariates keys dictionary (need for model fine tuning)
    cat_dict = {}
    if covariate_keys != None:
        for key in covariate_keys:
            categories = list(sorted(map(str, np.unique(adata_or_mdata.obs[key]))))
            cat_dict[key] = categories
    
    # Model initialization using modality-specific encoders and decoders
    model = mosesVAE(
        input_dims=input_dims,
        n_batches=dataset.n_batches,
        random_state=random_state,
        latent_dim=latent_dim,
        cov_dim=cov_dim,
        hidden_dim=hidden_dim,
        dropout=dropout,
        dropout_classifier=dropout_classifier,
        n_celltypes=dataset.n_celltypes,
        modalities_keys=dataset.modalities_keys,
        cat_dict = cat_dict,
        covariate_info = dataset.covariate_info
    ).to(device)

    # Compute covariates complexity
    if cov_dim > 0 and model.cov_conditioner is not None:
        # Use full training dataset for robust complexity estimation
        train_covariates = dataset.covariates[train_idx].to(device)
        complexity_weights = compute_covariate_complexity_weights(
            train_covariates, 
            dataset.covariate_info
        )
        model.cov_conditioner.set_complexity_weights(complexity_weights)
    
    # Model compilation (boost training)
    if device=='cuda':
        try:
            for mod in model.encoders:
                model.encoders[mod] = torch.compile(model.encoders[mod], mode='default', fullgraph=True)
                model.decoders[mod] = torch.compile(model.decoders[mod], mode='default', fullgraph=True)
            if model.n_modalities > 1:
                model.latent_combiner = torch.compile(model.latent_combiner, mode='default', fullgraph=True)
            model.discriminator = torch.compile(model.discriminator, mode='default', fullgraph=True)
            if cov_dim>0:
                model.cov_conditioner = torch.compile(model.cov_conditioner, mode='default', fullgraph=True)
        except:
            print("Warning: torch.compile failed")

    if hasattr(adata_or_mdata, "mod"):  # MuData
        model.feature_names = {}
        for key in adata_or_mdata.mod.keys():
            model.feature_names[key] = adata_or_mdata.mod[key].var_names.tolist()
    else:
        model.feature_names = adata_or_mdata.var_names.tolist()

    # Optimizers
    enc_params, dec_params, other_params = [], [], []
    for mod in model.encoders:
        enc_params += list(model.encoders[mod].parameters())
    for mod in model.decoders:
        dec_params += list(model.decoders[mod].parameters())
    if model.n_modalities > 1:
        other_params += list(model.latent_combiner.parameters())
    if model.cov_dim > 0:
        other_params += list(model.cov_conditioner.parameters())

    optimizer_vae = torch.optim.AdamW(
        [
            {'params': enc_params,   'lr': 1e-4, 'betas': (0.9, 0.95), 'weight_decay': 1e-4},
            {'params': dec_params,   'lr': 2e-4, 'betas': (0.9, 0.95), 'weight_decay': 1e-4},
            {'params': other_params, 'lr': 2e-4, 'betas': (0.9, 0.95), 'weight_decay': 1e-4},
        ]
    )
    
    optimizer_disc = torch.optim.AdamW(model.discriminator.parameters(), lr=2e-4, betas=(0.9, 0.95), weight_decay=1e-4)

    # Class weights
    class_weights = None
    if celltype_key is not None:
        if isinstance(celltype_settings, list):
            cw = compute_class_weight('balanced',
                classes=np.unique(adata_or_mdata.obs[celltype_key]),
                y=adata_or_mdata.obs[celltype_key])
            class_weights = torch.tensor(np.log1p(cw), dtype=torch.float).to(device)
        else: 
            assert ValueError('celltype_settings should be a list with a maximum value of label_weight and a mode of label weightening')

    # Kl_cap
    kl_cap, stats = estimate_kl_cap(dataset, device=device)
    
    kl_scheduler = KL_Scheduler(kl_cap, total_steps=len(train_loader) * epochs)

    # Warmup_epochs
    if warmup_epochs == 'auto':
        if len(dataset) > 100000:
            warmup_epochs = 40
        else:
            warmup_epochs = 80
            
    # Training
    history, model = train_moses_vae(
        model, train_loader, test_loader,
        optimizer_vae, optimizer_disc,
        epochs=epochs, device=device,
        noise_scale=noise_scale,
        patience=patience,
        cov_dim=cov_dim,
        batch_key=batch_key,
        celltype_key=celltype_key,
        celltype_settings=celltype_settings,
        noise_probability=noise_probability,
        warmup_epochs=warmup_epochs,
        n_celltypes=dataset.n_celltypes,
        class_weights=class_weights,
        kl_scheduler=kl_scheduler,
        verbose=verbose
    )
    model.history = history
    model.set_encoders_from_dataset(dataset)
    model.batch_key = batch_key
    model.kl_cap = kl_cap

    # Generating latent space
    all_mu = []
    full_loader = DataLoader(dataset, batch_size=10000, shuffle=False)
    model.eval()
    with torch.no_grad():
        for batch in full_loader:
            x_mods, cov, batch_lab, *extra = batch
            x_mods = {mod: x_mods[mod].to(device) for mod in x_mods}
            cov = cov.to(device)
            batch_lab = batch_lab.to(device)
            batch_onehot = F.one_hot(batch_lab, model.n_batches).float().to(device)
            mu, _, _ = model.encode(x_mods, cov, batch_onehot)
            all_mu.append(mu.cpu())
    mu_cat = torch.cat(all_mu, dim=0).numpy()
    adata_or_mdata.obsm[latent_key] = mu_cat
    torch.cuda.empty_cache()
    return model


# Function for generating latent space on a backed opened dataset
def train_backed(
    adata_or_mdata,
    latent_key = 'scMoses', 
    batch_key = None, 
    celltype_key = None,
    covariate_keys = None, 
    fraction = 50000, 
    chunk_size = 50000,
    celltype_settings = ['soft', 100],
    test_size = 0.1, 
    noise_scale = 0.001,
    noise_probability = 0.5,
    hidden_dim = 256, 
    dropout=0.1,
    dropout_classifier=0.2,
    latent_dim = 20, 
    patience = 10,
    batch_size = 128, 
    epochs = 500, 
    warmup_epochs = 'auto',
    device = 'auto', 
    use_hvg = True,
    feature_list = None,
    random_state = 1, 
    verbose = True
):
    '''
    Train scMoses model on a `backed` mode opened dataset. 

    Parameters
    ----------
    adata_or_mdata: Backed opened AnnData or MuData object.
        e.g.: adata = sc.read_h5ad('adata.h5ad', backed = 'r')
    batch_key: str (default: None)
        The key in adata.obs that indicates batch identifiers for batch correction (e.g. 'sample').
    latent_key: str (default: 'X_scMoses')
        The key specifying where to store the latent representation in the adata_or_mdata.obsm.
    test_size: float (default: 0.1) 
        Fraction of the dataset to reserve as a test data during training.
    noise_scale: float (default: 0.001)
        Scale of noise added during training for regularization.
    noise_probability: float (default: 0.5)
        The probability of applying noise to a batch.
    covariate_keys: str (default: None) 
        List of keys in adata_or_mdata.obs used as covariates for conditioning the model.
    fraction: int or float (deefault: 50000)
        Number of cells that used for training scMoses model. The larger the fraction, the better the model generalizes.
        If the 'celltype_key' or 'batch_key' is specified, it is used for stratified data partitioning.
        Using 'celltype_key' takes precedence over using 'batch_key'.
        If a float value is specified, it must be between 0.0 and 1.0 and represent the fraction of the dataset to be included in adata_fraction.
        If an integer is specified, it must be less than the number of cells in the dataset. This number of cells will be randomly allocated from adata.
    chunk_size: int (default: 50000)
        Number of cells from adata_or_mdata to load into RAM for latent space generation.
        The number of cells depends on the amount of RAM and the time that can be spent processing the dataset. 
        A small chunk_size can lead to a long time to generate the latent space.
    hidden_dim: int (default: 256)
        Dimension of hidden layers in the scMoses model.
    dropout: float (default: 0.1)
        Portion of neurons in scMoses model that temporarily ignored during training (prevents overfitting).
    dropout_classifier: float (default: 0.2)
        Portion of neurons in scMoses classifier (works if celltype_key is not None) 
        that temporarily ignored during training (prevents classifier overfitting).
    latent_dim: int (default: 20)
        Dimension of the latent space learned by the scMoses model.
    random_state: int (default: 1)
        Seed for random number generators to ensure reproducibility.
    patience: int (default: 10)
        Number of consecutive epochs without improvement before performing early stopping.
    batch_size: int (default: 128)
        Number of samples per batch during training.
    epochs: int (default: 500)
        Maximum number of training epochs.
    warmup_epochs: int (default: 'auto')
        Number of epochs for warm-up of KL divergence weight.
    device: str (default: 'auto')
        Type of device to use for model training ('cpu' or 'cuda'). Set to 'auto' for automatic selection.
    use_hvg: bool (default: False)
        Whether to use highly variable genes for training.
    feature_list: list (default: None)
        Whether to use list of features for training.
    celltype_key: str (default: None)
        Key in adata_or_mdata.obs containing cell type labels, used for classification tasks.
    celltype_settings: list (default: ['soft', 100])
        Settings related to celltype weighting during training; you need to specify mode and weight.
        Two modes are available: 
        1) 'soft' mode — soft influence of cell type on the formation of the scMoses latent space (recommended weight: 100). 
        2) 'hard' mode — hard influence of cell type on the formation of the scMoses latent space (recommended weight: 1000).

    Returns
    -------
    Trained scMoses model and adds the latent space to adata_or_mdata.obsm.

    Example
    --------
    
    .. plot::
    
        # scMoses model training on a single dataset
        model = scparadise.scmoses.train(
            adata_or_mdata,
            latent_key = 'scMoses'
        )
        
        # scMoses model training with batch (and covariate) correction
        model = scparadise.scmoses.train(
            adata_or_mdata,
            latent_key = 'scMoses',
            batch_key = 'sample', 
            covariate_keys = ['sex', 'age'], # optional
            celltype_key = 'celltype' # optional
        )
        
    '''
    # Fix random state for reproducibility
    np.random.seed(random_state)
    torch.manual_seed(random_state)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(random_state)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False

    # Set device
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu') if device=='auto' else device
    
    if celltype_key is not None:
        adata_or_mdata_fraction = get_frac(adata_or_mdata, fraction=fraction, stratify=celltype_key)
    elif batch_key is not None:
        adata_or_mdata_fraction = get_frac(adata_or_mdata, fraction=fraction, stratify=batch_key)
    else:
        adata_or_mdata_fraction = get_frac(adata_or_mdata, fraction=fraction, stratify=None)
    
    # Train scMoses model on a fraction of adata_or_mdata
    if fraction <= 1:
        print(f"Training scMoses model using {round(fraction*len(adata_or_mdata))} cells of dataset")
    else:
        print(f"Training scMoses model using {fraction} cells of dataset")
    model = train(
        adata_or_mdata_fraction,
        latent_key = latent_key, 
        batch_key = batch_key, 
        celltype_key = celltype_key,
        covariate_keys = covariate_keys, 
        celltype_settings = celltype_settings,
        test_size = test_size, 
        noise_scale = noise_scale,
        noise_probability = noise_probability,
        hidden_dim = hidden_dim, 
        dropout = dropout,
        dropout_classifier = dropout_classifier,
        latent_dim = latent_dim, 
        patience = patience,
        batch_size = batch_size, 
        epochs = epochs, 
        warmup_epochs = warmup_epochs,
        device = device, 
        use_hvg = use_hvg,
        feature_list = feature_list,
        random_state = random_state, 
        verbose = verbose
    )
    
    # Generating latent space using model trained of fraction of adata_or_mdata    
    all_mu = []  
    all_idx = []
    model.eval()
    with torch.no_grad():
        # Random shuffle of adata_or_mdata obs names
        obs = adata_or_mdata.obs.copy()
        obs = obs.sample(frac=1, random_state=1)
        obs_names = obs.index.tolist()
        # Generating latent space using chunks of data
        for i in tqdm(range(0, len(obs_names), chunk_size), 'Generating latent space', colour='green', disable = not verbose):
            adata_fraction = adata_or_mdata[obs_names[i:i + chunk_size]].to_memory()
            # Saving random indexes 
            all_idx.extend(adata_fraction.obs_names.copy())
            # Generating chunk dataset
            dataset = scRNADataset(
                adata_fraction, 
                use_hvg=use_hvg, 
                feature_list=feature_list,
                batch_key=batch_key, 
                covariate_keys=covariate_keys, 
                celltype_key=celltype_key
            )
            loader = DataLoader(dataset, batch_size=10000, shuffle=False)
            for batch in loader:
                x_mods, cov, batch_labels, *extra = batch
                x_mods = {mod: x_mods[mod].to(device) for mod in x_mods}
                cov = cov.to(device)
                batch_labels = batch_labels.to(device)
                batch_onehot = F.one_hot(batch_labels, model.n_batches).float().to(device)
                mu, _, _ = model.encode(x_mods, cov, batch_onehot)
                all_mu.append(mu.cpu())
    mu_cat = torch.cat(all_mu, dim=0).numpy()
    # Sorting latent space using adata_or_mdata.obs_names
    position = pd.Index(adata_or_mdata.obs_names).get_indexer(all_idx)   # -1 means "not found" [web:42]
    mu_cat = np.array([x for _, _, x in sorted(zip(position, all_idx, mu_cat))])
    adata_or_mdata.obsm[latent_key] = mu_cat
    torch.cuda.empty_cache()
    
    return model


### Data denoising
def denoise(
    model,
    adata_or_mdata,
    denoised_layer='denoised',
    use_hvg=False,
    feature_list=None,
    return_log1p=True,
    preserve_zeros='soft', 
    zero_threshold=0.2, 
    device="auto"
):
    """
    Denoising data using a trained model
    For each modality, returns an np.ndarray with the same median row sum as in the original counts.

    Parameters
    ----------
    model: Trained scMoses model
    adata_or_mdata: AnnData or MuData object.
    denoised_layer: str, (default: 'denoised')
        The key in adata_or_mdata.layers to add denoised data.
    use_hvg: bool (default: False)
        Whether to use highly variable genes for training.
    feature_list: list (default: None)
        Whether to use list of features for training.
    return_log1p: bool, (default: True)
    preserve_zeros: str, (default: 'soft')
        The mode to preserve zeros from original gene expression.
        Two modes are available: 
        1) 'soft': Zero only if: original value = 0 AND denoised value < threshold (likely technical zero)\
        2) 'hard': Zero if original value = 0
    zero_threshold: float, (default: 0.2)
        The threshold for 'soft' mode in preserve_zeros parameter.
    device: str, (default: 'auto')
        Type of device to use for denoising('cpu' or 'cuda'). Set to 'auto' for automatic selection.

    Returns
    -------
    Adds new layer with denoised data to adata_or_mdata.layers. Default denoised layer name: 'denoised'
    """

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu') if device == 'auto' else device
    batch_key = model.batch_key
    covariate_keys = list(model.covariate_info.keys())
    
    dataset = scRNADataset(adata_or_mdata, use_hvg=use_hvg, feature_list=feature_list, batch_key=batch_key, covariate_keys=covariate_keys)
    loader = DataLoader(dataset, batch_size=10000, shuffle=False)
    recon_mods = {mod: [] for mod in dataset.modalities_keys}
    orig_mods = {mod: [] for mod in dataset.modalities_keys}

    model.eval()
    with torch.no_grad():
        for batch in loader:
            if len(batch) == 5:
                x_mods, cov, batch_labels, _, labels = batch
            else:
                x_mods, cov, batch_labels, _ = batch
            x_mods = {mod: x_mods[mod].to(device) for mod in x_mods}
            cov = cov.to(device) if cov.size(1) > 0 else torch.zeros(x_mods[list(x_mods.keys())[0]].size(0), 0, device=device)
            batch_labels = batch_labels.to(device)
            batch_onehot = F.one_hot(batch_labels, model.n_batches).float().to(device)
            mu, logvar, _ = model.encode(x_mods, cov, batch_onehot)
            z = model.reparameterize(mu, logvar)
            recon_x = model.decode(z, cov, batch_onehot)
            for mod in recon_mods:
                recon_mods[mod].append(recon_x[mod].cpu())
                orig_mods[mod].append(x_mods[mod].cpu())

    # Collect into arrays
    recon_mods = {mod: torch.cat(recon_mods[mod], dim=0).numpy() for mod in recon_mods}
    orig_mods = {mod: torch.cat(orig_mods[mod], dim=0).numpy() for mod in orig_mods}

    # Obtain the initial counts for each modality
    orig_data_dict = {}
    for mod in recon_mods:
        if hasattr(adata_or_mdata, 'mod'):  # MuData
            ad = adata_or_mdata.mod[mod]
            orig_data = ad.X
        else:  # AnnData
            orig_data = adata_or_mdata.X
        if hasattr(orig_data, "toarray"):
            orig_data = orig_data.toarray()
        orig_data_dict[mod] = np.asarray(orig_data)

    # Post-processing for each modality
    for mod in recon_mods:
        if hasattr(adata_or_mdata, 'mod'): 
            # Inverse log1p for denoising
            denoised_exp = np.expm1(recon_mods[mod])
            denoised_exp[denoised_exp < 0] = 0
    
            # Mask of zeros
            if preserve_zeros == 'hard':
                # Hard: Zero if original value = 0
                zero_mask = orig_data_dict[mod] == 0
                denoised_exp[zero_mask] = 0
                
            elif preserve_zeros == 'soft':
                # Soft: Zero only if:
                # - original value = 0 AND
                # - denoised value < threshold (likely technical zero)
                zero_mask = orig_data_dict[mod] == 0
                low_denoised_mask = denoised_exp < zero_threshold
                combined_mask = zero_mask & low_denoised_mask
                denoised_exp[combined_mask] = 0
                
                n_preserved_zeros = np.sum(zero_mask)
                n_recovered = np.sum(zero_mask & ~low_denoised_mask)
                print(f"[{mod}] {n_recovered}/{n_preserved_zeros} dropout zeros restored"
                      f"({n_recovered/n_preserved_zeros*100:.1f}%)")
            
            elif preserve_zeros == 'none':
                pass
            
            else:
                raise ValueError(f"Unknown method to preserve_zeros: {preserve_zeros}")
    
            # Adjust the median of total counts per cell
            orig_totals = orig_data_dict[mod].sum(axis=1)
            median_orig = np.median(orig_totals)
            denoised_totals = denoised_exp.sum(axis=1)
            median_denoised = np.median(denoised_totals)
            scale = median_orig / (median_denoised + 1e-10)
            denoised_exp_scaled = denoised_exp * scale
    
            # (Optional) return log1p-normalized values
            if return_log1p:
                adata_or_mdata.mod[mod].layers[denoised_layer] = np.log1p(denoised_exp_scaled)
            else:
                adata_or_mdata.mod[mod].layers[denoised_layer] = denoised_exp_scaled
        else:
            denoised_exp = np.expm1(recon_mods[mod])
            denoised_exp[denoised_exp < 0] = 0 
    
            # Mask of zeros
            if preserve_zeros == 'hard':
                # Hard: Zero if original value = 0
                zero_mask = orig_data_dict[mod] == 0
                denoised_exp[zero_mask] = 0
                
            elif preserve_zeros == 'soft':
                # Soft: Zero only if:
                # - original value = 0 AND
                # - denoised value < threshold (likely technical zero)
                zero_mask = orig_data_dict[mod] == 0
                low_denoised_mask = denoised_exp < zero_threshold
                combined_mask = zero_mask & low_denoised_mask
                denoised_exp[combined_mask] = 0
                
                n_preserved_zeros = np.sum(zero_mask)
                n_recovered = np.sum(zero_mask & ~low_denoised_mask)
                print(f"[{mod}] {n_recovered}/{n_preserved_zeros} dropout zeros restored"
                      f"({n_recovered/n_preserved_zeros*100:.1f}%)")
            
            elif preserve_zeros == 'none':
                pass
            
            else:
                raise ValueError(f"Unknown method to preserve_zeros: {preserve_zeros}")
    
            # Fitting the median of total counts per cell
            orig_totals = orig_data_dict[mod].sum(axis=1)
            median_orig = np.median(orig_totals)
            denoised_totals = denoised_exp.sum(axis=1)
            median_denoised = np.median(denoised_totals)
            scale = median_orig / (median_denoised + 1e-10)
            denoised_exp_scaled = denoised_exp * scale
            
            if return_log1p:
                adata_or_mdata.layers[denoised_layer] = np.log1p(denoised_exp_scaled)
            else:
                adata_or_mdata.layers[denoised_layer] = denoised_exp_scaled


### ATAC-seq
# Generate gene activity matrix from ATAC-seq data
def generate_gene_activity(
    adata_peaks, 
    gtf_path
):
    """
    Generates a gene activity matrix from scATAC-seq anndata with peaks.
    
    Parameters
    ----------
    adata_peaks: AnnData with ATAC-seq peaks.
    gtf_path: str, path object
        Path to gtf file with genes annotation.
        
    Returns
    -------
    New AnnData: .X is the cell x gene matrix, .var is the gene table.
    """

    # GTF loading
    gene_ranges = {}  # gene_id -> (chr, start, end, gene_name)
    with gzip.open(gtf_path, 'rt') as f:
        for line in f:
            if line.startswith('#'): continue
            parts = line.strip().split('\t')
            feature = parts[2]
            if feature not in ('gene', 'transcript'): continue
            chromosome = parts[0]
            start = int(parts[3])
            end = int(parts[4])
            gene_id = parts[8].split(' ')[1].split('"')[1]
            gene_name = parts[8].split(' ')[5].split('"')[1]
            if gene_id and gene_id not in gene_ranges:
                gene_ranges[gene_id] = (chromosome, start, end, gene_name)

    # Assembling the mapping: which peaks correspond to which genes
    peaks_df = adata_peaks.var.copy().reset_index()
    def parse_peak(s):
        m = re.match(r'^(chr[\w]+):(\d+)-(\d+)$', s)
        if m:
            return m.group(1), int(m.group(2)), int(m.group(3))
        else:
            return None, None, None
    peaks_df[['chr', 'p_start', 'p_end']] = peaks_df['gene_ids'].apply(lambda x: pd.Series(parse_peak(x)))
    index_to_pos = {idx: pos for pos, idx in enumerate(adata_peaks.var.index)}
    peaks_by_chr = {chrom: df_chr for chrom, df_chr in peaks_df.groupby('chr')}

    # Filter genes with peaks and build a matrix
    row_inds = []
    col_inds = [] 
    gene_ids_filtered = [] 
    
    for gene_id, (g_chr, g_start, g_end, g_name) in gene_ranges.items():
        df_chr = peaks_by_chr.get(g_chr)
        if df_chr is None:
            continue
            
        cond = (df_chr['p_start'] <= g_end) & (df_chr['p_end'] >= g_start)
        overlapping_peaks = df_chr[cond]
        numeric_indices = [index_to_pos[idx] for idx in overlapping_peaks['index'] if idx in index_to_pos]
        
        if len(numeric_indices) == 0:
            continue 
            
        # Add only if there are peaks
        row_inds.extend(numeric_indices)
        col_inds.extend([len(gene_ids_filtered)] * len(numeric_indices))
        gene_ids_filtered.append(gene_id)

    if len(gene_ids_filtered) == 0:
        raise ValueError('No genes with overlapping peaks!')

    # Matrix multiplication (now only for genes with peaks)
    data = np.ones(len(row_inds), dtype=np.float32)
    peak_to_gene = sp.coo_matrix((data, (row_inds, col_inds)), 
                                 shape=(adata_peaks.X.shape[1], len(gene_ids_filtered)))
    
    cell_x_gene = adata_peaks.X @ peak_to_gene
    if sp.issparse(cell_x_gene):
        cell_x_gene = cell_x_gene.toarray()

    # Creating AnnData only for genes with activity
    var_df = pd.DataFrame({
        'gene_id': gene_ids_filtered,
        'gene_name': [gene_ranges[gid][3] for gid in gene_ids_filtered]
    })

    cell_x_gene = np.nan_to_num(cell_x_gene, nan=0.0, posinf=0.0, neginf=0.0)
    adata_gene_activity = anndata.AnnData(
        X=sp.csr_matrix(cell_x_gene, dtype = np.float32),
        obs=adata_peaks.obs.copy(),
        var=var_df.set_index('gene_name')
    )
    return adata_gene_activity


def encode_covariates(adata, covariate_dict):
    """ 
    adata — AnnData/MuData; covariate_dict — {feature: [cat1, cat2, ...]} 
    """
    features = []
    for key, cats in covariate_dict.items():
        col = adata.obs[key].astype(str) if key in adata.obs else [''] * adata.n_obs
        code = np.zeros((adata.n_obs, len(cats)))
        for i, cat in enumerate(cats):
            code[:, i] = (col == cat).astype(float)
        features.append(code)
    if features:
        return np.concatenate(features, axis=1)
    else:
        return np.zeros((adata.n_obs, 0))

# Function to align a genes in a new dataset to a genes used for model training
def align_to_model_genes(adata, model_genes, use_raw=True):
    n_cells = adata.n_obs
    n_genes = len(model_genes)
    X_new = np.zeros((n_cells, n_genes), dtype=np.float32)
    if use_raw and hasattr(adata, "raw") and adata.raw is not None:
        adata_genes = list(adata.raw.var_names)
        X_source = adata.raw.X
    else:
        adata_genes = list(adata.var_names)
        X_source = adata.X
    gene_to_idx = {g: i for i, g in enumerate(adata_genes)}
    for j, g in enumerate(model_genes):
        if g in gene_to_idx:
            idx = gene_to_idx[g]
            col = X_source[:, idx]
            if issparse(col):
                col = col.toarray().ravel()
            X_new[:, j] = col
    return X_new

### Mapping
def map_dataset(
    model,
    new_adata_or_mdata,
    batch_key=None,
    covariate_keys=None,
    celltype_key=None,
    celltype_settings=[100, 'soft'],
    latent_key='X_scMoses',
    epochs=500,
    warmup_epochs = 100,
    test_size = 0.1,
    batch_size=128,
    patience=10,
    device='auto',
    noise_scale=0.001,
    random_state = 1
):
    """
    Map new dataset using pretrained scMoses model. 

    Parameters
    ----------
    model: pretrained scMoses model.
    new_adata_or_mdata: new AnnData or MuData object.
    batch_key: str (default: None)
        The key in new_adata_or_mdata.obs that indicates batch identifiers for batch correction (e.g. 'sample').
    covariate_keys: str (default: None) 
        List of keys in new_adata_or_mdata.obs used as covariates for conditioning the model.
    celltype_key: str (default: None)
        Key in new_adata_or_mdata.obs containing cell type labels, used for classification tasks.
    celltype_settings: list (default: [100, 'soft'])
        Settings related to celltype weighting during training; you need to specify weight and mode.
        Two modes are available: 
        1) 'soft' mode — soft influence of cell type on the formation of the scMoses latent space (recommended weight: 100). 
        2) 'hard' mode — hard influence of cell type on the formation of the scMoses latent space (recommended weight: 1000).
    latent_key: str (default: 'X_scMoses')
        The key specifying where to store the latent representation in the adata_or_mdata.obsm.
    test_size: float (default: 0.1) 
    epochs: int (default: 500)
        Maximum number of training epochs.
    warmup_epochs: int (default: 'auto')
        Number of epochs for warm-up of KL divergence weight.
    test_size: float (default: 0.1) 
        Fraction of the dataset to reserve as a test data during training.
    batch_size: int (default: 128)
        Number of samples per batch during training.
    patience: int (default: 10)
        Number of consecutive epochs without improvement before performing early stopping.
    device: str (default: 'auto')
        Type of device to use for model training ('cpu' or 'cuda'). Set to 'auto' for automatic selection.
    noise_scale: float (default: 0.001)
        Scale of noise added during training for regularization.
    random_state: int (default: 1)
        Seed for random number generators to ensure reproducibility.
    
    Returns
    -------
    Fine-tuned scMoses model and adds the latent space to new_adata_or_mdata.obsm.
    
    """

    # Random state fixation
    np.random.seed(random_state)
    torch.manual_seed(random_state)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(random_state)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False

    # Device definition
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu') if device == 'auto' else torch.device(device)
    model = model.to(device)
    model.train()

    # Obtain a list of genes from the model
    model_genes = getattr(model, 'var_names', None)
    
    # Automatic alignment of data across model genes
    if hasattr(new_adata_or_mdata, "mod"):  # MuData
        # Create new_mdata
        new_mdata = new_adata_or_mdata.copy()
        
        for mod in model.modalities_keys:
            ad = new_mdata.mod[mod]
            X_aligned = align_to_model_genes(ad, model_genes[mod] if isinstance(model_genes, dict) else model_genes)
            
            # Create new AnnData for madality
            new_mdata.mod[mod] = anndata.AnnData(
                X=X_aligned,
                obs=ad.obs.copy(),
                var=pd.DataFrame(index=model_genes[mod] if isinstance(model_genes, dict) else model_genes)
            )
        
        new_adata = new_mdata
        
    else:  # AnnData
        X_aligned = align_to_model_genes(new_adata_or_mdata, model_genes)
        new_adata = anndata.AnnData(
            X=X_aligned,
            obs=new_adata_or_mdata.obs.copy(),
            var=pd.DataFrame(index=model_genes)
        )

    # Prepare dataset
    dataset = scRNADataset(
        new_adata,
        use_hvg=False,
        feature_list=None,
        batch_key=batch_key,
        covariate_keys=covariate_keys,
        celltype_key=celltype_key
    )

    if warmup_epochs == 'auto':
        if len(dataset) > 100000:
            warmup_epochs = 40
        else:
            warmup_epochs = 80
            
    # Encode covariates
    X_cov_new = encode_covariates(new_adata, model.cat_dict)
    cov_tensor = torch.tensor(X_cov_new, dtype=torch.float32)

    # Data split
    inds = np.arange(len(dataset))
    if batch_key is not None:
        train_idx, test_idx = train_test_split(
            inds, test_size=test_size,
            stratify=new_adata.obs[batch_key], random_state=1
        )
    else:
        train_idx, test_idx = train_test_split(
            inds, test_size=test_size,
            stratify=None, random_state=random_state
        )
    # Create train_loader for model training and test_loader for model validation
    train_loader = DataLoader(Subset(dataset, train_idx), batch_size=batch_size, shuffle=True)
    test_loader = DataLoader(Subset(dataset, test_idx), batch_size=batch_size, shuffle=False)

    # kl_cap
    kl_cap, kl_cap_stats = estimate_kl_cap(dataset, device=device)
    kl_scheduler = KL_Scheduler(kl_cap, total_steps=len(train_loader) * epochs)

    # Optimizer
    enc_params, dec_params, other_params = [], [], []
    for mod in model.encoders:
        enc_params += list(model.encoders[mod].parameters())
    for mod in model.decoders:
        dec_params += list(model.decoders[mod].parameters())
    if model.n_modalities > 1:
        other_params += list(model.latent_combiner.parameters())
    if model.cov_dim > 0:
        other_params += list(model.cov_conditioner.parameters())

    # Create optimizer for encoder, decoder and other model elements except discriminator
    optimizer_vae = torch.optim.AdamW(
        [
            {'params': enc_params,   'lr': 1e-4, 'betas': (0.9, 0.95), 'weight_decay': 1e-4},
            {'params': dec_params,   'lr': 2e-4, 'betas': (0.9, 0.95), 'weight_decay': 1e-4},
            {'params': other_params, 'lr': 2e-4, 'betas': (0.9, 0.95), 'weight_decay': 1e-4},
        ]
    )
    # Create optimizer for model discriminator
    optimizer_disc = torch.optim.AdamW(model.discriminator.parameters(), lr=2e-4, betas=(0.9, 0.95), weight_decay=1e-4)

    total_steps = epochs * max(1, len(train_loader))
    warmup_steps = int(0.05 * total_steps)
    
    global_step = 0
    
    def vae_lr_lambda(step):
        if step < warmup_steps:
            return max(step / max(1, warmup_steps), 1e-3)
        progress = (step - warmup_steps) / max(1, total_steps - warmup_steps)
        return 0.3 + 0.7 * (1 - progress) ** 0.5  # sqrt decay вместо cosine
    
    def disc_lr_lambda(step):
        if step < warmup_steps:
            return max(0.5 * step / max(1, warmup_steps), 5e-4)
        return 1.0
    
    scheduler_vae = torch.optim.lr_scheduler.LambdaLR(optimizer_vae, vae_lr_lambda)
    scheduler_disc = torch.optim.lr_scheduler.LambdaLR(optimizer_disc, disc_lr_lambda)

    n_losses = 3  # recon, kl, adv
    if celltype_key is not None and hasattr(model, 'celltype_classifier') and model.celltype_classifier is not None:
        n_losses += 1
    loss_balancer = AdaptiveLossBalancer(n_losses).to(device)
    loss_balancer_val = AdaptiveLossBalancer(2).to(device)

    best_val_loss = float('inf')
    patience_counter = 0
    best_model_state = None
    
    # Дообучение
    best_loss = float("inf")
    patience_count = 0
    best_model_state = None
    history = {
        'train_loss': [],
        'vae_loss': [],
        'adv_loss': [],
        'celltype_loss': [],
        'test_loss': [],
        'kl_weight': [],
        'recon_loss_per_modality': {mod: [] for mod in model.modalities_keys}
    }

    global_step = 0
    
    for epoch in tqdm(range(epochs), desc='Tuning', colour='green'):
        model.train()
        
        total_train_loss = 0.0
        total_vae_loss = 0.0
        total_adv_loss = 0.0
        total_cov_loss = 0.0
        total_celltype_loss = 0.0
        
        current_noise = noise_scale * (epoch / epochs)
        for batch in train_loader:
            if len(batch) == 5:
                x_mods, cov, batch_labels, idx, labels = batch
            else:
                x_mods, cov, batch_labels, idx = batch
                labels = None

            cov = cov_tensor[idx]
            x_mods = {mod: x_mods[mod].to(device) for mod in x_mods}
            
            if cov.size(1) == 0 and hasattr(model, 'cov_dim') and model.cov_dim > 0:
                cov = torch.zeros(x_mods[list(x_mods.keys())[0]].size(0), model.cov_dim, device=device)
            else:
                cov = cov.to(device)
            batch_labels = batch_labels.to(device)

            # Add noise to data
            if current_noise > 0:
                x_mods = {mod: torch.clamp(x + torch.randn_like(x) * current_noise, 0, 1) for mod, x in x_mods.items()}

            recon_x, mu, logvar, z, domain_pred, celltype_pred, valid_modalities = model.forward(
                x_mods, cov, batch_labels
            )

            # Reconstruction loss
            recon_loss = 0.0
            for mod in valid_modalities:
                if x_mods[mod] is not None:
                    recon_loss_mod = F.binary_cross_entropy(recon_x[mod], x_mods[mod], reduction='sum')
                    recon_loss += recon_loss_mod
            recon_loss_norm = recon_loss / len(train_loader.dataset)

            # Kl loss
            kl_weight = kl_scheduler.value(global_step)
            kl_loss = -kl_weight * torch.sum(1 + logvar - mu.pow(2) - logvar.exp()) 
            kl_loss_norm = kl_loss / len(train_loader.dataset)
            history['kl_weight'].append(float(kl_weight))
            global_step += 1

            # Adversarial loss
            if batch_key is not None:
                adv_loss = F.cross_entropy(domain_pred, batch_labels)
                adv_loss_norm = adv_loss / len(train_loader.dataset)
            else:
                adv_loss_norm = torch.tensor(0.0, device=device)

            # Cell type loss
            if celltype_key is not None and model.celltype_classifier is not None:
                labels = labels.to(device) if labels is not None else None
                mask = labels >= 0 if labels is not None else torch.ones(z.size(0), dtype=torch.bool, device=device)
                celltype_pred = model.celltype_classifier(z)
                cell_loss = F.cross_entropy(celltype_pred[mask], labels[mask], weight=class_weights)
                if celltype_settings[1] == 'soft':
                    t =  epoch / max(epoch, 150)
                    label_weight = celltype_settings[0] * (1.0 / (1.0 + math.exp(-10 * (t - 0.5))))
                    label_weight = min([label_weight, celltype_settings[0]])
                elif celltype_settings[1] == 'hard':
                    label_weight = 1 + (2000 * (epoch / epochs))
                    label_weight = min([label_weight, celltype_settings[0]])
                else:
                    assert ValueError('Mode of celltype weightening should be `hard` or `soft`')
                celltype_loss_norm = label_weight * cell_loss / len(train_loader.dataset)
            else:
                celltype_loss_norm = torch.tensor(0.0, device=device)
                
            # Combine losses
            losses = [recon_loss_norm, kl_loss_norm, adv_loss_norm]
            if celltype_key is not None and model.celltype_classifier is not None:
                losses.append(celltype_loss_norm)
            # Balance losses
            total_loss = loss_balancer(losses)
            
            optimizer_vae.zero_grad()
            optimizer_disc.zero_grad()
            total_loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            optimizer_vae.step()
            optimizer_disc.step()
            
            total_train_loss += total_loss.item()
            total_vae_loss += (recon_loss_norm.item() + kl_loss_norm.item())
            total_adv_loss += adv_loss_norm.item()
            total_celltype_loss += celltype_loss_norm.item()

            scheduler_vae.step()
            scheduler_disc.step()

        n_batches = len(train_loader)
        history['train_loss'].append(total_train_loss / n_batches)
        history['vae_loss'].append(total_vae_loss / n_batches)
        history['adv_loss'].append(total_adv_loss / n_batches)
        history['celltype_loss'].append(total_celltype_loss / n_batches)

        # Validation
        model.eval()
        test_loss = 0.0
        with torch.no_grad():
            for batch in test_loader:
                if len(batch) == 5:
                    x_mods_val, cov_val, batch_val, idx_val, _ = batch
                else:
                    x_mods_val, cov_val, batch_val, idx_val = batch

                cov_val = cov_tensor[idx_val]
                x_mods_val = move_dict_to_device(x_mods_val, device)
                batch_size = x_mods_val[list(x_mods_val.keys())[0]].size(0)
                if cov_val.size(1) == 0 and hasattr(model, 'cov_dim') and model.cov_dim > 0:
                    cov_val = torch.zeros(batch_size, model.cov_dim, device=device)
                else:
                    cov_val = cov_val.to(device)
                batch_val = batch_val.to(device)
                batch_onehot_val = F.one_hot(batch_val, model.n_batches).float().to(device)
                mu_val, logvar_val, _ = model.encode(x_mods_val, cov_val, batch_onehot_val)
                z_val = model.reparameterize(mu_val, logvar_val)

                # Recon loss
                recon_val = model.decode(z_val, cov_val, batch_onehot_val)
                recon_loss_val = 0.0
                for mod in model.modalities_keys:
                    present_mask = (x_mods_val[mod].sum(dim=1) != 0)
                    if present_mask.any():
                        recon_loss_val += F.binary_cross_entropy(
                            recon_val[mod][present_mask], x_mods_val[mod][present_mask], reduction='sum'
                        )
                recon_loss_val_norm = recon_loss_val / len(batch)

                # Kl loss
                kl_loss_val = -kl_weight * torch.sum(1 + logvar_val - mu_val.pow(2) - logvar_val.exp())
                kl_loss_val_norm = kl_loss_val / len(batch)

                test_losses = [recon_loss_val_norm, kl_loss_val_norm]
                test_loss = loss_balancer_val(test_losses)

        history['test_loss'].append(test_loss / len(test_loader.dataset))

        if epoch > warmup_epochs:
            if history['test_loss'][-1] < best_loss:
                best_loss = history['test_loss'][-1]
                patience_count = 0
                best_model = copy.deepcopy(model)
                best_model.best_epoch = epoch
            else:
                patience_count += 1
                if patience_count >= patience:
                    print(f"Early stopping at epoch {epoch+1}")
                    break

    # Adding latent space to the new dataset
    best_model.eval()
    loader = DataLoader(dataset, batch_size=10000, shuffle=False)
    all_mu = []
    with torch.no_grad():
        for batch in loader:
            if len(batch) == 5:
                x_mods, cov, batch_labels, idx, _ = batch
            else:
                x_mods, cov, batch_labels, idx = batch

            cov = cov_tensor[idx]
            x_mods = {mod: x_mods[mod].to(device) for mod in x_mods}
            if cov.size(1) == 0 and hasattr(model, 'cov_dim') and model.cov_dim > 0:
                cov = torch.zeros(x_mods[list(x_mods.keys())[0]].size(0), model.cov_dim, device=device)
            else:
                cov = cov.to(device)
            batch_labels = batch_labels.to(device)
            batch_onehot = F.one_hot(batch_labels, best_model.n_batches).float().to(device)
            mu, _, _ = best_model.encode(x_mods, cov, batch_onehot)
            all_mu.append(mu.cpu())
    mu_cat = torch.cat(all_mu, dim=0).numpy()
    new_adata_or_mdata.obsm[latent_key] = mu_cat
    
    return best_model

### Annotation block
def get_hvg_expression(adata, hvg_list, use_raw=False):
    if use_raw and hasattr(adata, "raw") and adata.raw is not None:
        X = adata.raw[:, hvg_list].X
    else:
        X = adata[:, hvg_list].X
    if hasattr(X, "toarray"):
        X = X.toarray()
    return X
    
def build_features(adata, hvg_list, latent_key='X_scMoses', use_raw=True):
    X_latent = adata.obsm[latent_key]
    X_hvg = get_hvg_expression(adata, hvg_list, use_raw=use_raw)
    features = np.concatenate([X_latent, X_hvg], axis=1)
    return features

# Create 3 different classifiers for cell type classification
# First classifier
class MLP1(nn.Module):
    def __init__(self, input_dim, hidden_dim, n_classes):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.BatchNorm1d(hidden_dim),
            nn.Linear(hidden_dim, n_classes)
        )
    def forward(self, x):
        return self.net(x)
        
# Second classifier
class MLP2(nn.Module):
    def __init__(self, input_dim, hidden_dim, n_classes):
        super().__init__()
        self.net = nn.Sequential(
                LatentAttention(input_dim),
                nn.Linear(input_dim, hidden_dim),
                nn.LayerNorm(hidden_dim),
                nn.GELU(),
                nn.Dropout(0.2),
                nn.Linear(hidden_dim, n_classes)
            )
    def forward(self, x):
        return self.net(x)

# Third classifier
class MLP3(nn.Module):
    def __init__(self, input_dim, hidden_dim, n_classes):
        super().__init__()
        self.fc1 = nn.Linear(input_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, n_classes)
    def forward(self, x):
        x = F.leaky_relu(self.fc1(x))
        return self.fc2(x)

# Train cell type classifier
def train_classifier(
    adata_ref, 
    model, 
    celltype_key, 
    use_raw = None,
    latent_key='X_scMoses', 
    hidden_dim=256,
    epochs=100, 
    lr=1e-3, 
    batch_size=256, 
    test_size=0.1, 
    patience=10, 
    device='auto', 
    noise_scale=0.001, 
    random_state=1
):
    """
    Train cell type classifier for predicting cell types after mapping new dataset using pretrained scMoses model.

    Parameters
    ----------
    adata_ref: AnnData
        Annotated data matrix. Reference dataset used for training scMoses model and scMoses cell type classifier.
    model: Pretrained scMoses model
    celltype_key: str (default: None)
        Key in adata_ref.obs containing cell type labels, used for traing cell type classifier.
    use_raw: bool or None (default: None)
        Whether to use raw attribute of adata_ref. Defaults to True if .raw is present in adata_ref.
    latent_key: str (default: 'X_scMoses')
        The key specifying where stored the latent representation in the adata_ref.obsm.
    hidden_dim: int (default: 256)
        Dimension of hidden layers in the scMoses cell type classifier.
    epochs: int (default: 100)
        Maximum number of training epochs.
    lr: float (default: 1e-3) 
        Model learning rate
    batch_size: int (default: 256)
        Number of samples per batch during training.
    test_size: float (default: 0.1) 
        Fraction of the dataset to reserve as a test data during training.
    patience: int (default: 10)
        Number of consecutive epochs without improvement before performing early stopping.
    device: str (default: 'auto')
        Type of device to use for model training ('cpu' or 'cuda'). Set to 'auto' for automatic selection.
    noise_scale: float (default: 0.001)
        Scale of noise added during training for regularization.
    random_state: int (default: 1)
        Seed for random number generators to ensure reproducibility.

    Returns:
        Modified scMoses model with trained cell type classifier. 

    Example
    -------

    .. plot::
    
        import scparadise

        # scMoses model training 
        model = scparadise.scmoses.train(
            adata_ref,
            latent_key = 'scMoses',
            batch_key = 'sample', # optional
            covariate_keys = ['sex', 'age'], # optional
            celltype_key = 'celltype' # optional
        )
        # Training classifier
        model = scparadise.scmoses.train_classifier(
            adata_ref,
            model,
            celltype_key='celltype',
            latent_key='scMoses'
        )
    
    """
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu') if device == 'auto' else torch.device(device)

    # Create list of genes for model training
    lst_genes = []
    # Check raw existence in adata_ref
    if use_raw == None:
        if hasattr(adata_ref.raw, 'X'):
            use_raw = True
        else:
            use_raw = False
    # Find marker genes
    sc.tl.rank_genes_groups(
        adata_ref, 
        use_raw = use_raw,
        groupby = celltype_key,
        method = 't-test_overestim_var', 
        pts = True
    )
    # Filter marker genes of cell types
    sc.tl.filter_rank_genes_groups(
        adata_ref, 
        min_fold_change = 1.0, 
        min_in_group_fraction = 0.4,
        key_added = 'filtered_rank_genes_groups'
    )
    
    # Append list with cell-type-specific marker genes
    for i in adata_ref.obs[celltype_key].unique():
        df = sc.get.rank_genes_groups_df(adata_ref, group = i, key = 'filtered_rank_genes_groups', pval_cutoff = 0.05)
        df['pts_comparizon'] = df['pct_nz_group']/df['pct_nz_reference']
        lst_genes.extend(df.sort_values(by = 'logfoldchanges', ascending = False).head(20)['names'].tolist()) # highly expressed genes
        lst_genes.extend(df.sort_values(by = 'pts_comparizon', ascending = False).head(20)['names'].tolist()) # most specific genes
        
    # Remove duplicates 
    lst_genes = np.unique(lst_genes).tolist()
    # Remove 'filtered_rank_genes_groups' from adata_ref.uns
    del adata_ref.uns['filtered_rank_genes_groups']
    # Random shuffle of marker genes
    random.shuffle(lst_genes)
    
    X = build_features(adata_ref, lst_genes, latent_key, use_raw=False)
    y = adata_ref.obs[celltype_key].values
    label_encoder = LabelEncoder()
    y_enc = label_encoder.fit_transform(y)
    n_classes = len(label_encoder.classes_)
    input_dim = X.shape[1]
    class_weights = torch.tensor(
        np.log1p(compute_class_weight('balanced', classes=np.unique(y_enc), y=y_enc)),
        dtype=torch.float
    ).to(device)

    idx = np.arange(len(X))
    train_idx, val_idx = train_test_split(idx, test_size=test_size, stratify=y_enc, random_state=random_state)
    X_train, X_val = X[train_idx], X[val_idx]
    y_train, y_val = y_enc[train_idx], y_enc[val_idx]

    train_dataset = torch.utils.data.TensorDataset(torch.FloatTensor(X_train), torch.LongTensor(y_train))
    val_dataset = torch.utils.data.TensorDataset(torch.FloatTensor(X_val), torch.LongTensor(y_val))
    train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    val_loader = torch.utils.data.DataLoader(val_dataset, batch_size=batch_size, shuffle=False)
    
    # Список различных моделей
    model_classes = [
        lambda: MLP1(input_dim, hidden_dim, n_classes),
        lambda: MLP2(input_dim, hidden_dim, n_classes),
        lambda: MLP3(input_dim, hidden_dim, n_classes)
    ]
    n_models = len(model_classes)
    classifiers = []
    histories = []

    for model_fn, model_idx in zip(model_classes, range(n_models)):

        clf = model_fn().to(device)
        optimizer = torch.optim.AdamW(clf.parameters(), lr=lr, weight_decay=1e-4)
        criterion = nn.CrossEntropyLoss(weight=class_weights)
        best_val_loss = float('inf')
        patience_counter = 0
        best_clf = None
        history = {'train_loss': [], 'val_loss': [], 'val_acc': []}

        for epoch in tqdm(range(epochs), desc=f'Training model {model_idx+1}/{n_models}', colour='green'):
            clf.train()
            total_loss = 0.0
            for xb, yb in train_loader:
                xb, yb = xb.to(device), yb.to(device)
                if noise_scale > 0:
                    xb = xb + torch.randn_like(xb) * noise_scale
                optimizer.zero_grad()
                logits = clf(xb)
                loss = criterion(logits, yb)
                loss.backward()
                optimizer.step()
                total_loss += loss.item() * xb.size(0)
            train_loss = total_loss / len(train_loader.dataset)
            history['train_loss'].append(train_loss)

            clf.eval()
            val_loss = 0.0
            correct = 0
            total = 0
            with torch.no_grad():
                for xb, yb in val_loader:
                    xb, yb = xb.to(device), yb.to(device)
                    logits = clf(xb)
                    loss = criterion(logits, yb)
                    val_loss += loss.item() * xb.size(0)
                    preds = torch.argmax(logits, dim=1)
                    correct += (preds == yb).sum().item()
                    total += xb.size(0)
            val_loss /= len(val_loader.dataset)
            val_acc = correct / total
            history['val_loss'].append(val_loss)
            history['val_acc'].append(val_acc)

            if val_loss < best_val_loss:
                best_val_loss = val_loss
                best_clf = copy.deepcopy(clf)
                patience_counter = 0
            else:
                patience_counter += 1
                if patience_counter >= patience:
                    print(f"Early stopping at epoch {epoch+1}")
                    break

        best_clf.eval()
        classifiers.append(best_clf)
        histories.append(history)

    # Add classifier elements to model
    model.lst_genes = lst_genes
    model.ensemble_input_dim = input_dim
    model.ensemble_hidden_dim = hidden_dim
    model.celltype_classifiers = classifiers
    model.celltype_key = celltype_key
    model.label_encoder = label_encoder
    model.n_celltypes = n_classes
    model.classifiers_histories = histories
    
    return model

def safe_hvg_expression(adata, hvg_list, use_raw=True):
    present = [g for g in hvg_list if g in adata.var_names]
    missing = [g for g in hvg_list if g not in adata.var_names]
    X_present = get_hvg_expression(adata, present, use_raw=use_raw)
    X_missing = np.zeros((adata.n_obs, len(missing)))
    X_hvg = np.zeros((adata.n_obs, len(hvg_list)))
    idx_present = [hvg_list.index(g) for g in present]
    idx_missing = [hvg_list.index(g) for g in missing]
    X_hvg[:, idx_present] = X_present
    X_hvg[:, idx_missing] = X_missing
    return X_hvg

def build_features_query(adata, hvg_list, latent_key='X_scMoses', use_raw=True):
    X_latent = adata.obsm[latent_key]
    X_hvg = safe_hvg_expression(adata, hvg_list, use_raw=use_raw)
    features = np.concatenate([X_latent, X_hvg], axis=1)
    return features

# Predict cell types using trained scMoses classifier
def predict(
    adata_query, 
    model, 
    latent_key, 
    correction = True, 
    use_raw = False, 
    n_neighbors = 30,
    n_iterations = 3,
    rare_cells = 0.01, 
    min_confidence = 0.5,
    device='auto'
):
    """
    Predict cell type annotation using pretrained scMoses classifier and fine tuned scMoses model.
    scMoses model fine tuning 
    
    Parameters
    ----------
    adata_ref: AnnData
        Annotated data matrix. Reference dataset used for training scMoses model and scMoses cell type classifier.
    model: Pretrained scMoses model
    celltype_key: str (default: None)
        Key in adata_ref.obs containing cell type labels, used for traing cell type classifier.
    use_raw: bool or None (default: None)
        Whether to use raw attribute of adata_ref. Defaults to True if .raw is present in adata_ref.
    latent_key: str (default: 'X_scMoses')
        The key specifying where stored the latent representation in the adata_ref.obsm.
    hidden_dim: int (default: 256)
        Dimension of hidden layers in the scMoses cell type classifier.
    epochs: int (default: 100)
        Maximum number of training epochs.
    lr: float (default: 1e-3) 
        Model learning rate
    batch_size: int (default: 256)
        Number of samples per batch during training.
    test_size: float (default: 0.1) 
        Fraction of the dataset to reserve as a test data during training.
    patience: int (default: 10)
        Number of consecutive epochs without improvement before performing early stopping.
    device: str (default: 'auto')
        Type of device to use for model training ('cpu' or 'cuda'). Set to 'auto' for automatic selection.
    noise_scale: float (default: 0.001)
        Scale of noise added during training for regularization.
    random_state: int (default: 1)
        Seed for random number generators to ensure reproducibility.

    Returns:
        Modified scMoses model with trained cell type classifier. 

    Example
    -------
    
    .. plot::
    
        import scparadise

        # Run after:
        # scparadise.scmoses.train
        # scparadise.scmoses.train_classifier
        
        # Load model
        model_loaded = scparadise.scmoses.mosesVAE.load_model('model.pth')
        # Fine tune model
        model_tuned = scparadise.scmoses.map_dataset(
            model_loaded,
            adata_query,
            latent_key = 'scMoses_query',
            batch_key = batch_key,
            covariate_keys = covariate_keys
        )
        # Cell type prediction
        scparadise.scmoses.predict(
            adata_query,
            model_loaded,
            latent_key = 'scMoses_query'
        )
    """
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu') if device == 'auto' else torch.device(device)
    clf = model.celltype_classifier
    label_encoder = model.label_encoder
    X_query = build_features_query(adata_query, hvg_list=model.lst_genes, latent_key=latent_key, use_raw=use_raw)
    X_tensor = torch.FloatTensor(X_query).to(device)
    all_probs = []
    for clf in model.celltype_classifiers:
        clf.eval()
        with torch.no_grad():
            logits = clf(X_tensor)
            probs = F.softmax(logits, dim=1).cpu().numpy()
            all_probs.append(probs)
    mean_probs = np.mean(all_probs, axis=0)
    preds = np.argmax(mean_probs, axis=1)
    adata_query.obs[f'pred_{model.celltype_key}'] = model.label_encoder.inverse_transform(preds)  
    adata_query.obs[f'prob_{model.celltype_key}'] = np.max(mean_probs, axis=1)
    if correction:
        iterative_correct(
            adata_query, 
            celltype_key=f'pred_{model.celltype_key}',
            corrected_key=f'corr_{model.celltype_key}',
            latent_key=latent_key,
            n_neighbors=n_neighbors,
            n_iterations=n_iterations,
            min_confidence=min_confidence, 
            rare_cells=rare_cells
        )

### Correct cell type annotation
# Correct cell type annotation using KNN-graph
def knn_correct(
    adata_or_mdata, 
    celltype_key=None,
    corrected_key='knn_corrected',
    n_neighbors=15, 
    latent_key='X_scMoses', 
    rare_cells=0.01,
    min_confidence=0.5
):
    """
    Correct cell type annotation using the neighborhood graph derived from the integrated scMoses latent space.
    This function is equal to scparadise.scmose.iterative_correct function with parameter n_iterations = 1.

    Parameters
    ----------
    adata_or_mdata: AnnData or MuData object.
    celltype_key: str (default: None)
        Key in adata_or_mdata.obs containing cell type labels, used for correction.
    corrected_key: str (default: 'knn_corrected')
        Key in adata_or_mdata.obs to add corrected cell type labels.
    n_neighbors: int (default: 15)
        The size of local neighborhood (in terms of number of neighboring data points) used for manifold approximation.
        The same parameter in function scanpy.pp.neighbors.
    latent_key: str (default: 'X_scMoses')
        The key specifying where to store the latent representation in the adata_or_mdata.obsm.
    rare_cells: float (default: 0.001)
        The proportion of rare cell types in the dataset that do not need to be corrected using the function knn_correct.
    min_confidence: float (default: 0.5)
        The proportion of cells in local neighborhood to correct cell types. If local neighborhood = 30 and 16 cells named 'T cell' then all cells will be named 'T cell'.
    
    Returns:
        Corrected cell type annotation in adata_or_mdata.obs[corrected_key].

    """
    # Check celltype_key and latent_key
    if celltype_key not in adata_or_mdata.obs:
        raise ValueError(f"There is no {celltype_key} in adata_or_mdata.obs")

    if latent_key not in adata_or_mdata.obsm:
        raise ValueError(f"There is no {latent_key} in adata_or_mdata.obsm")
        
    # Copy predictions made by model
    adata_or_mdata.obs[corrected_key] = adata_or_mdata.obs[celltype_key].copy()

    # Calculate neighbors
    sc.pp.neighbors(adata_or_mdata, n_neighbors=n_neighbors, key_added='correction', use_rep=latent_key)
    
    # Get connectivities
    neighbors_graph = adata_or_mdata.obsp['correction'+'_connectivities']
    
    # Analyze nearest neighbors for each cells
    for cell_idx in range(adata_or_mdata.n_obs):
        # Obtain the neighbors indices
        neighbors_idx = neighbors_graph[cell_idx].nonzero()[1]

        # Skipping cells without neighbors
        if len(neighbors_idx) == 0:
            continue  
        
        # Get neighbors cell types
        neighbor_types = adata_or_mdata.obs[celltype_key].iloc[neighbors_idx].values
        
        # Count the frequency of each type
        type_counts = pd.Series(neighbor_types).value_counts(normalize=True)
        
        # Get current cell type
        current_type = adata_or_mdata.obs[celltype_key].iloc[cell_idx]
        
        # Rename cells based on a predominant neighbors
        if len(type_counts) > 0 and type_counts.index[0] != current_type and type_counts.iloc[0] >= min_confidence:
            adata_or_mdata.obs.loc[adata_or_mdata.obs.index[cell_idx], corrected_key] = type_counts.index[0]

    # Rare cells
    if isinstance(rare_cells, float):
        if rare_cells < 1.0:
            min_cluster_size=adata_or_mdata.n_obs*rare_cells
            rare_labels = adata_or_mdata.obs[celltype_key].value_counts()[adata_or_mdata.obs[celltype_key].value_counts() < min_cluster_size].index
        else:
            min_cluster_size=rare_cells
            rare_labels = adata_or_mdata.obs[celltype_key].value_counts()[adata_or_mdata.obs[celltype_key].value_counts() < min_cluster_size].index
    elif isinstance(rare_cells, int):
        min_cluster_size=rare_cells
        rare_labels = adata_or_mdata.obs[celltype_key].value_counts()[adata_or_mdata.obs[celltype_key].value_counts() < min_cluster_size].index
    elif isinstance(rare_cells, list):
        rare_labels = adata_or_mdata[adata_or_mdata.obs[celltype_key].isin(rare_cells)].obs[celltype_key].value_counts().index
    if rare_cells != None:
        adata_or_mdata.obs[corrected_key] = adata_or_mdata.obs.apply(
            lambda x: x[corrected_key] if x[celltype_key] not in rare_labels else x[celltype_key], 
            axis=1
        )

# Iterative correction of cell type annotation using KNN-graph
def iterative_correct(
    adata_or_mdata, 
    celltype_key = None,
    corrected_key = 'iterative_corrected',
    n_neighbors = 15, 
    latent_key = 'X_scMoses', 
    rare_cells = 0.01,
    min_confidence = 0.5,
    n_iterations = 3
):
    """
    Iterative correction of cell type annotation using the neighborhood graph derived from the integrated scMoses latent space.
    
    Parameters
    ----------
    adata_or_mdata: AnnData or MuData object.
    celltype_key: str (default: None)
        Key in adata_or_mdata.obs containing cell type labels, used for correction.
    corrected_key: str (default: 'knn_corrected')
        Key in adata_or_mdata.obs to add corrected cell type labels.
    n_neighbors: int (default: 15)
        The size of local neighborhood (in terms of number of neighboring data points) used for manifold approximation.
        The same parameter in function scanpy.pp.neighbors.
    latent_key: str (default: 'X_scMoses')
        The key specifying where to store the latent representation in the adata_or_mdata.obsm.
    rare_cells: float (default: 0.01)
        The proportion of rare cell types in the dataset that do not need to be corrected using the function knn_correct.
    min_confidence: float (default: 0.5)
        The proportion of cells in local neighborhood to correct cell types. If local neighborhood = 30 and 16 cells named 'T cell' then all cells will be named 'T cell'.
    n_iterations: int (default: 3)
        The number of iterations for cell type correction using local neighborhood.

    Returns:
        Corrected cell type annotation in adata_or_mdata.obs[corrected_key].
        
    """
    # Check celltype_key and latent_key
    if celltype_key not in adata_or_mdata.obs:
        raise ValueError(f"There is no {celltype_key} in adata_or_mdata.obs")

    if latent_key not in adata_or_mdata.obsm:
        raise ValueError(f"There is no {latent_key} in adata_or_mdata.obsm")
        
    # Copy annotation
    adata_or_mdata.obs[corrected_key] = adata_or_mdata.obs[celltype_key].copy()

    # Calculate neighbors
    sc.pp.neighbors(adata_or_mdata, n_neighbors=n_neighbors, key_added='correction', use_rep=latent_key)
    
    # Get connectivities
    neighbors_graph = adata_or_mdata.obsp['correction'+'_connectivities']
    
    # Analyze nearest neighbors for each cells for n_iterations
    for i in range(n_iterations):
        for cell_idx in range(adata_or_mdata.n_obs):
            # Получаем индексы соседей
            neighbors_idx = neighbors_graph[cell_idx].nonzero()[1]
    
            # Skipping cells without neighbors
            if len(neighbors_idx) == 0:
                continue  
            
            # Get neighbors cell types
            neighbor_types = adata_or_mdata.obs[corrected_key].iloc[neighbors_idx].values
            
            # Count the frequency of each type
            type_counts = pd.Series(neighbor_types).value_counts(normalize=True)
            
            # Get current cell type
            current_type = adata_or_mdata.obs[corrected_key].iloc[cell_idx]
            
            # Rename cells based on a predominant neighbors
            if len(type_counts) > 0 and type_counts.index[0] != current_type and type_counts.iloc[0] >= min_confidence:
                adata_or_mdata.obs.loc[adata_or_mdata.obs.index[cell_idx], corrected_key] = type_counts.index[0]

    # Rare cells
    if isinstance(rare_cells, float):
        if rare_cells < 1.0:
            min_cluster_size=adata_or_mdata.n_obs*rare_cells
            rare_labels = adata_or_mdata.obs[celltype_key].value_counts()[adata_or_mdata.obs[celltype_key].value_counts() < min_cluster_size].index
        else:
            min_cluster_size=rare_cells
            rare_labels = adata_or_mdata.obs[celltype_key].value_counts()[adata_or_mdata.obs[celltype_key].value_counts() < min_cluster_size].index
    elif isinstance(rare_cells, int):
        min_cluster_size=rare_cells
        rare_labels = adata_or_mdata.obs[celltype_key].value_counts()[adata_or_mdata.obs[celltype_key].value_counts() < min_cluster_size].index
    elif isinstance(rare_cells, list):
        rare_labels = adata_or_mdata[adata_or_mdata.obs[celltype_key].isin(rare_cells)].obs[celltype_key].value_counts().index
    if rare_cells != None:
        adata_or_mdata.obs[corrected_key] = adata_or_mdata.obs.apply(
            lambda x: x[corrected_key] if x[celltype_key] not in rare_labels else x[celltype_key], 
            axis=1
        )
        
### Spatial deconvolution
# Simple spatial deconvolution
def deconvolve_spatial(
    adata_spatial, 
    adata_sc, 
    model, 
    batch_key = None,
    covariate_keys = None,
    celltype_key = 'celltype',
    batch_size = 512,
    use_raw = True,
    latent_key = None,
    device = 'auto'
) -> anndata.AnnData:
    """
    Деконволюция пространственных данных Visium HD с использованием обученной модели mosesVAE.
    
    Параметры:
        adata_spatial (AnnData): Пространственные данные (Visium HD).
        adata_sc (AnnData): scRNA-seq данные с аннотацией типов клеток.
        model (mosesVAE): Обученная модель mosesVAE.
        celltype_key (str): Ключ в adata_sc.obs для аннотации типов клеток.
        batch_size (int): Размер батча для инференса.
        device (str): Устройство для вычислений ('cuda' или 'cpu').
    
    Возвращает:
        AnnData: adata_spatial с добавленными пропорциями типов клеток в .obsm['deconvolution'].
    """
    # Определение устройства
    if device == 'auto':
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    elif (device == 'cpu') or (device == 'cuda'):
        device = torch.device(device)
    else:
        raise ValueError("Device should be 'auto', 'cuda' or 'cpu'.")
        
    model = model.to(device)
    model.eval()
    
    # Проверка наличия аннотации типов клеток
    if celltype_key not in adata_sc.obs:
        raise ValueError(f"Celltype key {celltype_key} not found in adata_sc.obs")
    
    # Проверка генов модели
    if not hasattr(model, 'var_names'):
        raise ValueError("Модель не содержит информацию о генах. Используйте model.set_encoders_from_dataset()")
    
    # 1. Выравнивание генов по модели
    model_genes = model.var_names
    n_genes = len(model_genes)
    
    # Создаем новые AnnData объекты с генами в порядке модели
    def align_to_model_genes(adata, use_raw):
        X_new = np.zeros((adata.n_obs, n_genes))
        
        # Находим индексы общих генов
        if use_raw == True:
            common_genes, idx_adata, idx_model = np.intersect1d(
                adata.raw.var_names, model_genes, return_indices=True
            )
            
            # Заполняем общие гены
            if issparse(adata.X):
                X_new[:, idx_model] = adata.raw[:, common_genes].X.toarray()
            else:
                X_new[:, idx_model] = adata.raw[:, common_genes].X
                
            return anndata.AnnData(
                X=X_new,
                obs=adata.obs.copy(),
                var=pd.DataFrame(index=model_genes)
            )
        else:
            common_genes, idx_adata, idx_model = np.intersect1d(
                adata.var_names, model_genes, return_indices=True
            )
            
            # Заполняем общие гены
            if issparse(adata.X):
                X_new[:, idx_model] = adata[:, common_genes].X.toarray()
            else:
                X_new[:, idx_model] = adata[:, common_genes].X
                
            return anndata.AnnData(
                X=X_new,
                obs=adata.obs.copy(),
                var=pd.DataFrame(index=model_genes)
            )
        print(f'Common genes between datasets: {len(common_genes)}')
    
    adata_spatial_aligned = align_to_model_genes(adata_spatial, use_raw = use_raw)
    adata_sc_aligned = align_to_model_genes(adata_sc, use_raw = False)
    
    # 2. Подготовка ковариат и батчей
    cov_dim = model.cov_dim
    n_batches = model.n_batches
    
    # Создание DataLoader для scRNA данных
    class SingleCellDataset(torch.utils.data.Dataset):
        def __init__(self, adata):
            # Genes
            self.X = torch.FloatTensor(adata.X)
            
            # Batches
            self.batch_labels = torch.zeros(len(adata), dtype=torch.long)
            
            # Covariates
            self.covariates = torch.zeros((len(adata), cov_dim)) if cov_dim > 0 else torch.zeros((len(adata), 0))
            
        def __len__(self):
            return len(self.X)
        
        def __getitem__(self, idx):
            # Get data for modality
            main_modality = model.modalities_keys[0]
            return {main_modality: self.X[idx]}, self.covariates[idx], self.batch_labels[idx]
    
    sc_dataset = scRNADataset(adata_sc_aligned, use_hvg=False, batch_key = batch_key, covariate_keys=covariate_keys, celltype_key=celltype_key)
    sc_loader = torch.utils.data.DataLoader(sc_dataset, batch_size=batch_size, shuffle=False)
    
    # Get latent space for scRNA-seq data
    latent_list = []
    
    with torch.no_grad():
        for batch in sc_loader:
            x_mods = {k: v.to(device) for k, v in batch[0].items()}
            cov = batch[1].to(device)
            batch_labels = batch[2].to(device)
            batch_onehot = F.one_hot(batch_labels, n_batches).float()
            
            mu, _, _ = model.encode(x_mods, cov, batch_onehot)
            latent_list.append(mu.cpu())
    
    latent_sc = torch.cat(latent_list, dim=0).numpy()
    adata_sc_aligned.obsm['X_latent'] = latent_sc
    
    # Calculation of reference profiles of cell types
    cell_types = adata_sc_aligned.obs[celltype_key].unique()
    ref_profiles = {}
    
    for ct in cell_types:
        mask = adata_sc_aligned.obs[celltype_key] == ct
        if latent_key == None:
            ref_profiles[ct] = np.median(adata_sc_aligned.obsm['X_latent'][mask], axis=0)
        else:
            adata_sc_aligned.obsm[latent_key] = adata_sc.obsm[latent_key] 
            ref_profiles[ct] = np.median(adata_sc_aligned.obsm[latent_key][mask], axis=0)
    
    # Reference profile matrix (cell_types x latent_dim)
    R = np.array([ref_profiles[ct] for ct in cell_types])
    
    # Obtaining latent representations for spatial data
    spatial_dataset = SingleCellDataset(adata_spatial_aligned)
    spatial_loader = torch.utils.data.DataLoader(spatial_dataset, batch_size=batch_size, shuffle=False)
    
    latent_spatial = []
    with torch.no_grad():
        for batch in spatial_loader:
            x_mods = {k: v.to(device) for k, v in batch[0].items()}
            cov = batch[1].to(device)
            batch_labels = batch[2].to(device)
            batch_onehot = F.one_hot(batch_labels, n_batches).float()
            
            mu, _, _ = model.encode(x_mods, cov, batch_onehot)
            latent_spatial.append(mu.cpu())
    
    latent_spatial = torch.cat(latent_spatial, dim=0).numpy()
    adata_spatial.obsm['X_latent'] = latent_spatial
    
    # Deconvolution using NNLS
    n_spots = latent_spatial.shape[0]
    n_celltypes = len(cell_types)
    proportions = np.zeros((n_spots, n_celltypes))
    
    for i in range(n_spots):
        w, _ = nnls(R.T, latent_spatial[i])
        if w.sum() > 0:
            w /= w.sum()
        else:
            w = np.ones(n_celltypes) / n_celltypes
        proportions[i] = w
    
    # Save results
    adata_spatial.obsm['deconvolution'] = proportions
    adata_spatial.uns['deconvolution_celltypes'] = cell_types

    for i, ct in enumerate(cell_types):
        adata_spatial.obs[f'{ct} proportion'] = proportions_np[:, i]
        
    return adata_spatial

# Fast bayesian deconvolution
def fast_bayesian_deconvolution(
    adata_spatial,
    adata_sc,
    model,
    batch_key = None,
    covariate_keys = None,
    celltype_key = 'celltype',
    use_raw = True,
    latent_key = 'X_latent',
    batch_size = 512,
    alpha_prior = 1.0,
    n_iter = 30,
    lr = 0.05,
    device = 'auto'
) -> anndata.AnnData:
    """
    Быстрая байесовская деконволюция пространственных данных с оптимизацией на GPU.
    """

    # Определение устройства
    if device == 'auto':
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    else:
        device = torch.device(device)
    model = model.to(device)
    model.eval()

    # Проверка аннотации типов клеток
    if celltype_key not in adata_sc.obs:
        raise ValueError(f"Ключ {celltype_key} не найден в adata_sc.obs")

    # Проверка генов модели
    if not hasattr(model, 'var_names'):
        raise ValueError("Модель не содержит информацию о генах (var_names)")

    model_genes = model.var_names
    n_genes = len(model_genes)

    # Вспомогательная функция выравнивания генов
    def align_to_model_genes(adata, use_raw):
        X_new = np.zeros((adata.n_obs, n_genes))
        if use_raw:
            common_genes, idx_adata, idx_model = np.intersect1d(
                adata.raw.var_names, model_genes, return_indices=True
            )
            if issparse(adata.raw.X):
                X_new[:, idx_model] = adata.raw[:, common_genes].X.toarray()
            else:
                X_new[:, idx_model] = adata.raw[:, common_genes].X
            return anndata.AnnData(
                X=X_new,
                obs=adata.obs.copy(),
                var=pd.DataFrame(index=model_genes)
            )
        else:
            common_genes, idx_adata, idx_model = np.intersect1d(
                adata.var_names, model_genes, return_indices=True
            )
            if issparse(adata.X):
                X_new[:, idx_model] = adata[:, common_genes].X.toarray()
            else:
                X_new[:, idx_model] = adata[:, common_genes].X
            return anndata.AnnData(
                X=X_new,
                obs=adata.obs.copy(),
                var=pd.DataFrame(index=model_genes)
            )

    adata_spatial_aligned = align_to_model_genes(adata_spatial, use_raw=use_raw)
    adata_sc_aligned = align_to_model_genes(adata_sc, use_raw=False)

    # Получение латентных представлений для scRNA-seq
    class SingleCellDataset(torch.utils.data.Dataset):
        def __init__(self, adata):
            self.X = torch.FloatTensor(adata.X)
            self.batch_labels = torch.zeros(len(adata), dtype=torch.long)
            self.covariates = torch.zeros((len(adata), 0))
        def __len__(self):
            return len(self.X)
        def __getitem__(self, idx):
            main_modality = model.modalities_keys[0]
            return {main_modality: self.X[idx]}, self.covariates[idx], self.batch_labels[idx]

    sc_dataset = scRNADataset(adata_sc_aligned, use_hvg=False, batch_key = batch_key, covariate_keys=covariate_keys, celltype_key=celltype_key)
    sc_loader = torch.utils.data.DataLoader(sc_dataset, batch_size=batch_size, shuffle=False)

    latent_list = []
    with torch.no_grad():
        for batch in sc_loader:
            x_mods = {k: v.to(device) for k, v in batch[0].items()}
            cov = batch[1].to(device)
            batch_labels = batch[2].to(device)
            batch_onehot = F.one_hot(batch_labels, model.n_batches).float()
            mu, _, _ = model.encode(x_mods, cov, batch_onehot)
            latent_list.append(mu.cpu())
    latent_sc = torch.cat(latent_list, dim=0).numpy()
    adata_sc_aligned.obsm['X_latent'] = latent_sc

    # Расчет референсных профилей типов клеток
    cell_types = adata_sc_aligned.obs[celltype_key].unique()
    ref_profiles = {}
    for ct in cell_types:
        mask = adata_sc_aligned.obs[celltype_key] == ct
        if latent_key == None:
            ref_profiles[ct] = np.median(adata_sc_aligned.obsm['X_latent'][mask], axis=0)
        else:
            adata_sc_aligned.obsm[latent_key] = adata_sc.obsm[latent_key] 
            ref_profiles[ct] = np.median(adata_sc_aligned.obsm[latent_key][mask], axis=0)

    R = np.stack([ref_profiles[ct] for ct in cell_types], axis=0)  # (n_celltypes, latent_dim)

    # Получение латентных представлений для spatial
    spatial_dataset = SingleCellDataset(adata_spatial_aligned)
    spatial_loader = torch.utils.data.DataLoader(spatial_dataset, batch_size=batch_size, shuffle=False)
    latent_spatial = []
    with torch.no_grad():
        for batch in spatial_loader:
            x_mods = {k: v.to(device) for k, v in batch[0].items()}
            cov = batch[1].to(device)
            batch_labels = batch[2].to(device)
            batch_onehot = F.one_hot(batch_labels, model.n_batches).float()
            mu, _, _ = model.encode(x_mods, cov, batch_onehot)
            latent_spatial.append(mu.cpu())
    latent_spatial = torch.cat(latent_spatial, dim=0).numpy()
    adata_spatial.obsm['X_latent'] = latent_spatial

    # Быстрая байесовская оптимизация на GPU
    R_torch = torch.tensor(R, device=device, dtype=torch.float32)  # (n_celltypes, latent_dim)
    Y_torch = torch.tensor(latent_spatial, device=device, dtype=torch.float32)  # (n_spots, latent_dim)
    n_spots = Y_torch.shape[0]
    n_celltypes = R_torch.shape[0]
    proportions = torch.full((n_spots, n_celltypes), 1.0 / n_celltypes, device=device, requires_grad=True)

    optimizer = torch.optim.Adam([proportions], lr=lr)
    for i in range(n_iter):
        optimizer.zero_grad()
        recon = torch.matmul(proportions, R_torch)  # (n_spots, latent_dim)
        loss = ((Y_torch - recon) ** 2).sum(dim=1).mean()
        prior = - (alpha_prior - 1) * torch.log(proportions + 1e-8).sum(dim=1).mean()
        total_loss = loss + prior
        total_loss.backward()
        optimizer.step()
        with torch.no_grad():
            proportions.clamp_(min=0)
            proportions.div_(proportions.sum(dim=1, keepdim=True))

    proportions_np = proportions.cpu().detach().numpy()
    adata_spatial.obsm['deconvolution'] = proportions_np
    adata_spatial.uns['deconvolution_celltypes'] = cell_types

    for i, ct in enumerate(cell_types):
        adata_spatial.obs[f'{ct} prop bs'] = proportions_np[:, i]

    return adata_spatial

### Modality imputation
# KNN-based modality imputation 
def impute_modality(
    mdata, 
    latent_key = 'X_scMoses', 
    modality = 'PROT', 
    neighbors_key = 'connectivities', 
    n_neighbors = 5
):
    """
    Modality imputation using latent space in mdata.

    mdata: Mudata object
        Object used for training scMoses model.
    latent_key='X_scMoses', 
    modality: str (default: 'PROT') 
        Modality name that you want to impute in your partially overlapping mdata.
        Imputation will be performed in cells where there is no modality or the modality values are equal to 0.
    neighbors_key: str (default: 'connectivities')
        Specifies which precomputed neighbors graph to use for imputation.
    n_neighbors: int (default: 5)
        The size of local neighborhood (in terms of number of neighboring data points) used for modality imputation.

    Returns:
        Imputed modality in cells where there is no modality or the modality values are equal to 0.
    """
    # Get cell indicies with modalities
    all_cells = np.array(mdata.obs_names)
    ad = mdata.mod[modality]
    present_cells = np.array(ad.obs_names)
    missing_cells = np.setdiff1sd(all_cells, present_cells, assume_unique=True)
    if len(missing_cells) == 0:
        return mdata

    # Cell indices
    cell_to_idx = {cell: i for i, cell in enumerate(all_cells)}
    present_mask = np.isin(all_cells, present_cells)
    present_indices = np.where(present_mask)[0]
    missing_indices = np.where(~present_mask)[0]

    # Connectivities graph
    neighbors_graph = mdata.obsp[neighbors_key].tocsr()

    # Для всех недостающих клеток сразу находим их соседей среди present_cells
    rows = neighbors_graph[missing_indices][:, present_indices]

    # Find k-nearest neighbors
    data = ad.X.toarray() if sp.issparse(ad.X) else ad.X
    imputed = []
    for i in range(rows.shape[0]):
        row = rows[i]
        if row.nnz == 0:
            imputed.append(data.mean(axis=0))
            continue
        # Indices of k most powerfull connections
        if row.nnz > n_neighbors:
            topk_idx = np.argpartition(-row.data, n_neighbors-1)[:n_neighbors]
            neighbors_idx = row.indices[topk_idx]
        else:
            neighbors_idx = row.indices
        imputed.append(data[neighbors_idx].mean(axis=0))
    imputed = np.vstack(imputed)

    # Create AnnData for imputed data
    new_obs = mdata.obs.loc[missing_cells].copy()
    new_var = ad.var.copy()
    imputed_ad = AnnData(X=imputed, obs=new_obs, var=new_var)
    imputed_ad.obs_names = missing_cells

    # Concatenate with real modality
    full_ad = ad.concatenate(imputed_ad, join='outer', batch_key=None, index_unique=None)
    full_ad = full_ad[all_cells, :]
    mdata.mod[modality] = full_ad
    return mdata


### GRN inference

class GRNBuilder:
    """
    Graph regulatory network (GRN) builder.

    Parameters
    ----------
    
    model: trained scMoses model
    adata: AnnData object with latent space generated by scMoses model
    latent_key: str (default: 'X_scMoses')
        Latent key in adata.obsm
    device : str (default: 'auto')
        Type of device to use in training model ('cpu', 'cuda'). Set 'auto' for automatic selection.
    """
    
    def __init__(self, model, adata, latent_key='X_scMoses', device='auto'):
        """
        GRNBuilder initialization
        """

        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu') if device=='auto' else device
        
        self.model = model
        self.adata = adata
        self.latent_key = latent_key
        self.device = device
        self.batch_key = getattr(self.model, 'batch_key', None)     
        self.feature_names = np.array(self._get_feature_names())
        self.n_genes = len(self.feature_names)
        
    def _get_feature_names(self):
        """Get gene names from model"""
        if hasattr(self.model, 'var_names'):
            if isinstance(self.model.var_names, dict):
                all_names = []
                for mod in self.model.modalities_keys:
                    all_names.extend(self.model.var_names.get(mod, []))
                return all_names
            else:
                return list(self.model.var_names)
    
    def get_cluster_data(
        self, 
        cluster_label, 
        cluster_key,
        filter_housekeeping=True,
        cv_threshold=0.3,
        high_expr_quantile=0.9
    ):
        
        """
        Get cluster data.
        """
        cluster_mask = self.adata.obs[cluster_key] == cluster_label
        cluster_indices = np.where(cluster_mask)[0]
        
        if len(cluster_indices) == 0:
            raise ValueError(f"Cluster {cluster_label} not found")
        
        X_cluster = self.adata.X
        if hasattr(X_cluster, 'toarray'):
            X_cluster = X_cluster.toarray()

        X_cluster = X_cluster.copy()
        # Filtering housekeeping genes
        gene_mask = np.ones(X_cluster.shape[1], dtype=bool)
        
        if filter_housekeeping:
            mean_expr = np.mean(X_cluster, axis=0)
            std_expr = np.std(X_cluster, axis=0)
            cv = std_expr / (mean_expr + 1e-10)  # Коэффициент вариации
            high_expr_threshold = np.quantile(mean_expr, high_expr_quantile)
            is_high_expr = mean_expr > high_expr_threshold
            is_low_variance = cv < cv_threshold
            housekeeping_mask = is_high_expr & is_low_variance
            gene_mask = ~housekeeping_mask
            X_cluster[:, housekeeping_mask] = 0.0
            
        X_cluster_norm = (X_cluster - X_cluster.min(0)) / (np.ptp(X_cluster, axis=0) + 1e-10)
        X_cluster_norm = X_cluster_norm[cluster_indices]

        # Get batch codes (if there is a batch_key)
        if self.batch_key and self.batch_key in self.adata.obs.columns:
            batch_labels = self.adata.obs[self.batch_key][cluster_indices].values
        else:
            # If there is no batch, use zeros
            batch_labels = np.zeros(len(cluster_indices), dtype=int)
        
        return cluster_indices, X_cluster_norm, batch_labels
    
    def compute_gene_importance_gradient(self, cluster_label, modality, cv_threshold, high_expr_quantile, cluster_key):
        """
        Get gene importance.
        """
        cluster_indices, X_cluster, batch_labels = self.get_cluster_data(cluster_label, cluster_key, cv_threshold=cv_threshold,
                    high_expr_quantile=high_expr_quantile)
        
        # Coding the batch
        if self.batch_key and hasattr(self.model, 'batch_encoder'):
            batch_encoded = torch.nn.functional.one_hot(
                torch.LongTensor(self.model.batch_encoder.transform(batch_labels)),
                num_classes=self.model.n_batches
            ).float().to(self.device)
        else:
            batch_encoded = torch.zeros(len(batch_labels), self.model.n_batches, device=self.device)
        
        # Preparing input data
        X_tensor = torch.FloatTensor(X_cluster).to(self.device)
        cov_tensor = torch.zeros(X_cluster.shape[0], self.model.cov_dim, device=self.device)
        
        self.model.eval()
        
        # Encode
        with torch.no_grad():
            mu, logvar, _ = self.model.encode(
                {modality: X_tensor},
                cov_tensor,
                batch_encoded
            )
            
            # Average latent representation of a cluster
            z_mean = mu.mean(dim=0, keepdim=True)
            recon = self.model.decode(z_mean, cov_tensor[:1], batch_encoded[:1])
            recon_genes = recon[modality]
        
        # Gradient analysis
        X_tensor_grad = X_tensor.clone().detach().requires_grad_(True)
        
        mu_grad, logvar_grad, _ = self.model.encode(
            {modality: X_tensor_grad},
            cov_tensor,
            batch_encoded
        )
        
        # Use the latent space norm as the objective function
        z_norm = torch.norm(mu_grad, dim=1).sum()
        z_norm.backward(retain_graph=True)
        
        # Gradient of input genes
        if X_tensor_grad.grad is not None:
            gene_grads = X_tensor_grad.grad.abs().mean(dim=0).cpu().numpy()
        else:
            gene_grads = np.ones(self.n_genes)
        
        mean_expr = X_cluster.mean(axis=0)
        
        # Determine the expression threshold
        positive_expr = mean_expr[mean_expr > 0]
        if len(positive_expr) > 0:
            threshold = np.percentile(positive_expr, 25)
        else:
            threshold = 0.1
        
        expressed_mask = mean_expr > threshold
        
        # Combining the gradient and expression
        gene_importance = gene_grads * mean_expr
        gene_importance[~expressed_mask] = 0
        
        # Create a Series for expressed genes only
        importance_df = pd.Series(
            gene_importance,
            index=self.feature_names[:self.n_genes]
        )
        
        # Фильтруем нулевые значения
        importance_df = importance_df[importance_df > 0].sort_values(ascending=False)
        
        return importance_df
    
    def compute_gene_correlations(self, cluster_label, cluster_key, cv_threshold, high_expr_quantile,
                                  min_correlation=0.3):
        """
        Calculate correlations between expressed genes
        """
        cluster_indices, X_cluster, _ = self.get_cluster_data(cluster_label, cluster_key, cv_threshold=cv_threshold,
                    high_expr_quantile=high_expr_quantile)
        
        # Check expressed genes
        mean_expr = X_cluster.mean(axis=0)
        
        expressed_genes = self.feature_names[:self.n_genes]
        # Normalize
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X_cluster)
        
        # Correlation matrix
        corr_matrix = np.corrcoef(X_scaled.T)
        
        # If there is only 1 gene
        if corr_matrix.ndim == 0:
            corr_matrix = np.array([[0]])
        
        # Reset weak correlations
        if corr_matrix.shape[0] > 1:
            corr_matrix[np.abs(corr_matrix) < min_correlation] = 0
            np.fill_diagonal(corr_matrix, 0)
        
        return corr_matrix, expressed_genes
    
    def build_grn(
        self, 
        cluster_label, 
        cluster_key, 
        modality = 'rna',
        top_genes_count=200,
        cv_threshold=0.5, 
        min_edge_weight=0.001, 
        high_expr_quantile=0.9,
        correlation_weight=0.4, 
        importance_weight=0.6
    ):
        """
        Construct a GRN from only expressed genes.
        """
        # Calculating the importance of genes
        gene_importance = self.compute_gene_importance_gradient(
            cluster_label=cluster_label, cluster_key=cluster_key, cv_threshold=cv_threshold, high_expr_quantile=high_expr_quantile, modality=modality
        )
        
        # Calculating correlations
        corr_matrix, expressed_genes = self.compute_gene_correlations(cluster_label=cluster_label, cluster_key=cluster_key, cv_threshold=cv_threshold, high_expr_quantile=high_expr_quantile)
        
        # Selecting top genes
        top_count = min(top_genes_count, len(gene_importance))
        top_genes = gene_importance.head(top_count).index.tolist()
        
        # Mapping to indexes in expressed_genes
        top_genes_idx = {gene: i for i, gene in enumerate(expressed_genes)}
        top_genes_in_expr = [g for g in top_genes if g in top_genes_idx]
        top_genes_idx_vals = [top_genes_idx[g] for g in top_genes_in_expr]
        
        # Creating graph
        G = nx.DiGraph()
        
        for gene in top_genes_in_expr:
            node_importance = gene_importance.get(gene, 0)
            G.add_node(gene, importance=node_importance)
        
        # Add edges
        edges_list = []
        
        for i_idx, i_local in enumerate(top_genes_idx_vals):
            gene_i = top_genes_in_expr[i_idx]
            
            for j_idx, j_local in enumerate(top_genes_idx_vals):
                if i_idx >= j_idx:
                    continue
                gene_j = top_genes_in_expr[j_idx]
                
                # Calculating the weight of an edge
                corr_weight_val = abs(corr_matrix[i_local, j_local])
                importance_val = (gene_importance[gene_i] + gene_importance[gene_j]) / 2
                
                # Combined weight
                edge_weight = (correlation_weight * corr_weight_val + 
                              importance_weight * importance_val)
                
                if edge_weight > min_edge_weight:
                    if gene_importance[gene_i] > gene_importance[gene_j]:
                        source, target = gene_i, gene_j
                    else:
                        source, target = gene_j, gene_i
                    
                    G.add_edge(source, target, weight=edge_weight)
                    edges_list.append({
                        'source': source,
                        'target': target,
                        'weight': edge_weight,
                        'correlation': corr_weight_val,
                        'source_importance': gene_importance[source],
                        'target_importance': gene_importance[target]
                    })
        
        edge_data = pd.DataFrame(edges_list) if edges_list else pd.DataFrame()
        
        return G, edge_data
    
    def visualize_grn(self, G, figsize=(8, 8), base_fontsize=9, node_size=500,
                     layout='spring', top_edges=30, show_edge_labels=False, random_state=1,
                     color_by='importance', style='publication'):
        """
        GRN visualization.
        
        Args:
        G: NetworkX graph
        figsize: tuple (default: (8, 8)) 
            Figure size.
        base_fontsize: int (default: 9) 
            Base size of gene signature.
        node_size: int (default: 500) 
            Node size scale.
        layout: str (defailt: 'spring') 
            Layout type ('spring', 'circular', 'kamada_kawai', 'hierarchical').
        top_edges: int or None (default: 30) 
            Number of top edges to display (None = all).
        show_edge_labels: bool (default: False) 
            Show edge weights.
        color_by: str (default: 'importance') 
            Node coloring ('importance', 'degree', 'community').
        style: str (default: 'publication') 
            visualization style ('publication', 'colorful', 'minimal').
            
        """
        
        # Выбираем рёбра для отображения
        if top_edges is not None and G.number_of_edges() > top_edges:
            edges_sorted = sorted(G.edges(data=True), 
                                key=lambda x: x[2]['weight'], 
                                reverse=True)[:top_edges]
            edge_pairs = [(u, v) for u, v, _ in edges_sorted]
            G_vis = G.edge_subgraph(edge_pairs).copy()
        else:
            G_vis = G.copy()
        
        # Create figure
        fig, ax = plt.subplots(figsize=figsize, facecolor='white')
        ax.set_facecolor('white')
        
        # Visualisation style
        if layout == 'spring':
            pos = nx.spring_layout(G_vis, k=1.5, iterations=100, seed=random_state)
        elif layout == 'circular':
            pos = nx.circular_layout(G_vis)
        elif layout == 'kamada_kawai':
            pos = nx.kamada_kawai_layout(G_vis)
        elif layout == 'hierarchical':
            # Иерархическая раскладка (TFs сверху)
            pos = nx.spring_layout(G_vis, k=2, iterations=50, seed=42)
            # Двигаем узлы с высоким out-degree вверх
            out_degrees = dict(G_vis.out_degree())
            max_out = max(out_degrees.values()) if out_degrees else 1
            for node in pos:
                out_deg = out_degrees.get(node, 0)
                pos[node][1] += 0.3 * (out_deg / max_out)
        else:
            pos = nx.spring_layout(G_vis, k=1.5, iterations=100, seed=42)
        
        # Coloring of nodes
        if color_by == 'importance':
            node_colors = [G_vis.nodes[node].get('importance', 0) for node in G_vis.nodes()]
            cmap = plt.cm.YlOrRd
            vmin, vmax = min(node_colors), max(node_colors)
            colorbar_label = 'Gene Importance'
        elif color_by == 'degree':
            node_colors = [G_vis.degree(node, weight='weight') for node in G_vis.nodes()]
            cmap = plt.cm.viridis
            vmin, vmax = min(node_colors), max(node_colors)
            colorbar_label = 'Network Degree'
        elif color_by == 'community':
            try:
                communities = nx.community.greedy_modularity_communities(G_vis.to_undirected())
                node_to_community = {}
                for i, comm in enumerate(communities):
                    for node in comm:
                        node_to_community[node] = i
                node_colors = [node_to_community.get(node, 0) for node in G_vis.nodes()]
                cmap = plt.cm.tab20
                vmin, vmax = 0, len(communities)
                colorbar_label = 'Community'
            except:
                node_colors = [0] * G_vis.number_of_nodes()
                cmap = plt.cm.Blues
                vmin, vmax = 0, 1
                colorbar_label = 'Default'
        else:
            node_colors = 'lightblue'
            cmap = None
            vmin, vmax = None, None
            colorbar_label = None
        
        # Nodes size
        node_sizes = []
        for node in G_vis.nodes():
            importance = G_vis.nodes[node].get('importance', 0.1)
            size = max(200, importance * node_size)
            node_sizes.append(size)
        
        # Edges parameters
        edge_weights = [G_vis[u][v]['weight'] for u, v in G_vis.edges()]
        if edge_weights:
            max_weight = max(edge_weights)
            min_weight = min(edge_weights)
            weight_range = max_weight - min_weight if max_weight > min_weight else 1
            
            if style == 'publication':
                edge_widths = [0.5 + 3.5 * ((w - min_weight) / weight_range) for w in edge_weights]
                edge_colors = ['#666666'] * len(edge_weights)
                edge_alpha = 0.6
            elif style == 'colorful':
                edge_widths = [0.5 + 4.5 * ((w - min_weight) / weight_range) for w in edge_weights]
                # Edges colors by weight
                edge_colors = [plt.cm.Greys(0.3 + 0.6 * ((w - min_weight) / weight_range)) 
                              for w in edge_weights]
                edge_alpha = 0.7
            else:  # minimal
                edge_widths = [0.3 + 2 * ((w - min_weight) / weight_range) for w in edge_weights]
                edge_colors = ['#CCCCCC'] * len(edge_weights)
                edge_alpha = 0.4
        else:
            edge_widths = [1.0]
            edge_colors = ['gray']
            edge_alpha = 0.5
        
        # Drawing a graph        
        # Drawing the edges
        nx.draw_networkx_edges(
            G_vis, pos,
            width=edge_widths,
            edge_color=edge_colors,
            alpha=edge_alpha,
            arrows=True,
            arrowsize=20,
            arrowstyle='->',
            node_size=node_sizes,
            connectionstyle='arc3,rad=0.1',  # Изогнутые рёбра
            ax=ax
        )
        
        # Drawing nodes
        if cmap is not None:
            nodes = nx.draw_networkx_nodes(
                G_vis, pos,
                node_size=node_sizes,
                node_color=node_colors,
                cmap=cmap,
                vmin=vmin,
                vmax=vmax,
                edgecolors='black',
                linewidths=2,
                ax=ax
            )
            
            # Color bar
            if colorbar_label and style != 'minimal':
                cbar = plt.colorbar(nodes, ax=ax, shrink=0.8, pad=0.02)
                cbar.set_label(colorbar_label, fontsize=12)
        else:
            nx.draw_networkx_nodes(
                G_vis, pos,
                node_size=node_sizes,
                node_color=node_colors,
                edgecolors='black',
                linewidths=2,
                ax=ax
            )
        
        # Signatures next to the nodes
        # Calculate offsets for labels (so that they do not overlap with nodes)
        text_objects = []
        for node, (x, y) in pos.items():
            # Determine the node size for the label offset
            node_idx = list(G_vis.nodes()).index(node)
            node_radius = np.sqrt(node_sizes[node_idx]) / 100  # Approximate radius
            
            # Signature offset (top-right of node)
            label_x = x + node_radius * 0.15
            label_y = y + node_radius * 0.08
            
            # Font size depends on importance
            importance = G_vis.nodes[node].get('importance', 0.1)
            fontsize = base_fontsize + int(2 * importance / max(node_colors) if node_colors else 0)
            fontsize = min(fontsize, 15)
            
            # Draw a signature with a background for readability
            text = ax.text(
                label_x, label_y, node,
                fontsize=fontsize,
                fontweight='bold',
                ha='left',
                va='bottom',
                bbox=dict(
                    boxstyle='round,pad=0.3',
                    facecolor='white',
                    edgecolor='none',
                    alpha=0.85
                ),
                zorder=100
            )
            text_objects.append(text)
        
        # Signatures of the edges scales
        if show_edge_labels and G_vis.number_of_edges() <= 50:
            edge_labels = {(u, v): f"{G_vis[u][v]['weight']:.2f}" 
                          for u, v in G_vis.edges()}
            nx.draw_networkx_edge_labels(
                G_vis, pos,
                edge_labels=edge_labels,
                font_size=7,
                font_color='darkred',
                bbox=dict(facecolor='white', edgecolor='none', alpha=0.7),
                ax=ax
            )
            
            # Adding information about top genes
            if color_by == 'importance':
                top_genes = sorted(G_vis.nodes(), 
                                 key=lambda x: G_vis.nodes[x].get('importance', 0), 
                                 reverse=True)[:3]
                legend_elements.append(
                    mpatches.Patch(color='none', 
                                 label=f'Top: {", ".join(top_genes)}')
                )
            
        ax.axis('off')
        plt.tight_layout()
        
        return fig
    
    def get_hub_genes(self, G, top_n=10):
        """
        Hub genes.
        """
        if G.number_of_nodes() == 0:
            return pd.DataFrame()
        
        in_degree = dict(G.in_degree(weight='weight'))
        out_degree = dict(G.out_degree(weight='weight'))
        
        hub_genes = []
        for gene in G.nodes():
            hub_genes.append({
                'gene': gene,
                'in_degree': in_degree.get(gene, 0),
                'out_degree': out_degree.get(gene, 0),
                'total_degree': in_degree.get(gene, 0) + out_degree.get(gene, 0),
                'importance': G.nodes[gene].get('importance', 0)
            })
        
        hub_df = pd.DataFrame(hub_genes).sort_values('total_degree', ascending=False)
        return hub_df

    def visualize_gene_as_regulator(self, G, gene_name, edge_data, figsize=(16, 12), base_fontsize=9,
                                    node_size_scale=500, layout='spring', top_edges=None, random_state=1,
                                    show_edge_labels=False, style='publication'):
        """
        Визуализирует ген как регулятор.
        Показывает ТОЛЬКО исходящие рёбра: gene_name → targets
        
        Args:
            G: NetworkX граф GRN
            gene_name: ген-регулятор для анализа
            edge_data: DataFrame с информацией о рёбрах (from build_grn)
            figsize: размер фигуры
            node_size_scale: масштаб размера узлов
            layout: тип раскладки ('spring', 'circular', 'kamada_kawai', 'hierarchical')
            top_edges: количество топ рёбер для отображения (None = все)
            show_edge_labels: показывать веса рёбер
            style: стиль визуализации ('publication', 'colorful', 'minimal')
        """
        
        # Получаем ТОЛЬКО исходящие рёбра (gene_name как source)
        outgoing_edges = edge_data[edge_data['source'] == gene_name].copy()
        
        # Сортируем по весу и берём топ
        outgoing_edges = outgoing_edges.sort_values('weight', ascending=False)
        if top_edges is not None:
            outgoing_edges = outgoing_edges.head(top_edges)
        
        # Создаём новый граф только с исходящими рёбрами
        G_vis = nx.DiGraph()
        
        # Добавляем целевой ген
        G_vis.add_node(gene_name, **G.nodes[gene_name])
        
        # Добавляем только исходящие рёбра и их мишени
        for _, row in outgoing_edges.iterrows():
            source = row['source']
            target = row['target']
            weight = row['weight']
            
            # Добавляем мишень
            if target in G.nodes():
                G_vis.add_node(target, **G.nodes[target])
            
            # Добавляем рёбро
            G_vis.add_edge(source, target, weight=weight)
        
        # Create figure
        fig, ax = plt.subplots(figsize=figsize, facecolor='white')
        ax.set_facecolor('white')
        
        # Visualisation style
        if layout == 'spring':
            pos = nx.spring_layout(G_vis, k=1.5, iterations=100, seed=random_state)
        elif layout == 'circular':
            pos = nx.circular_layout(G_vis)
        elif layout == 'kamada_kawai':
            pos = nx.kamada_kawai_layout(G_vis)
        elif layout == 'hierarchical':
            pos = nx.spring_layout(G_vis, k=2, iterations=50, seed=42)
            if gene_name in pos:
                pos[gene_name][1] = 0.9
        else:
            pos = nx.spring_layout(G_vis, k=1.5, iterations=100, seed=42)
        
        # Size and color of nodes
        node_colors = []
        node_sizes = []
        
        for node in G_vis.nodes():
            if node == gene_name:
                # Целевой ген - красный, большой
                node_colors.append('#FF6B6B')
                node_sizes.append(node_size_scale * 1.2)
            else:
                # Мишени - по важности
                importance = G_vis.nodes[node].get('importance', 0)
                node_colors.append(importance)
                node_sizes.append(max(200, importance * node_size_scale))
        
        # Edges parameters
        edge_weights = [G_vis[u][v]['weight'] for u, v in G_vis.edges()]
        
        if edge_weights:
            max_weight = max(edge_weights)
            min_weight = min(edge_weights)
            weight_range = max_weight - min_weight if max_weight > min_weight else 1
            
            if style == 'publication':
                edge_widths = [0.5 + 3.5 * ((w - min_weight) / weight_range) for w in edge_weights]
                edge_colors = ['#666666'] * len(edge_weights)
                edge_alpha = 0.6
            elif style == 'colorful':
                edge_widths = [0.5 + 4.5 * ((w - min_weight) / weight_range) for w in edge_weights]
                edge_colors = [plt.cm.Greys(0.3 + 0.6 * ((w - min_weight) / weight_range)) 
                              for w in edge_weights]
                edge_alpha = 0.7
            else:  # minimal
                edge_widths = [0.3 + 2 * ((w - min_weight) / weight_range) for w in edge_weights]
                edge_colors = ['#CCCCCC'] * len(edge_weights)
                edge_alpha = 0.4
        else:
            edge_widths = [1.0]
            edge_colors = ['gray']
            edge_alpha = 0.5
        
        nx.draw_networkx_edges(
            G_vis, pos,
            width=edge_widths,
            edge_color=edge_colors,
            alpha=edge_alpha,
            arrows=True,
            arrowsize=20,
            arrowstyle='->',
            node_size=node_sizes,
            connectionstyle='arc3,rad=0.1',
            ax=ax
        )
        
        # Create nodes
        non_target_nodes = [n for n in G_vis.nodes() if n != gene_name]
        
        if non_target_nodes:
            non_target_sizes = [node_sizes[list(G_vis.nodes()).index(n)] for n in non_target_nodes]
            non_target_colors = [node_colors[list(G_vis.nodes()).index(n)] for n in non_target_nodes]
            
            nx.draw_networkx_nodes(
                G_vis.subgraph(non_target_nodes), pos,
                node_size=non_target_sizes,
                node_color=non_target_colors,
                cmap=plt.cm.YlOrRd,
                vmin=0,
                vmax=max(non_target_colors) if non_target_colors else 1,
                edgecolors='black',
                linewidths=2,
                ax=ax
            )
        
        # Target gene
        nx.draw_networkx_nodes(
            G_vis.subgraph([gene_name]), pos,
            node_size=[node_size_scale * 1.2],
            node_color=['#FF6B6B'],
            edgecolors='darkred',
            linewidths=3,
            ax=ax
        )
        
        # Node signatures
        for node, (x, y) in pos.items():
            node_idx = list(G_vis.nodes()).index(node)
            node_radius = np.sqrt(node_sizes[node_idx]) / 100
            
            label_x = x + node_radius * 0.15
            label_y = y + node_radius * 0.08
            
            # Font size
            if node == gene_name:
                fontsize = 14
                fontweight = 'bold'
                bbox_color = 'darkred'
            else:
                importance = G_vis.nodes[node].get('importance', 0.1)
                max_importance = max([G_vis.nodes[n].get('importance', 0.1) 
                                     for n in G_vis.nodes() if n != gene_name])
                fontsize = base_fontsize + int(2 * importance / max_importance if max_importance else 0)
                fontsize = min(fontsize, 14)
                fontweight = 'normal'
                bbox_color = 'gray'
            
            ax.text(
                label_x, label_y, node,
                fontsize=fontsize,
                fontweight=fontweight,
                ha='left',
                va='bottom',
                bbox=dict(
                    boxstyle='round,pad=0.3',
                    facecolor='white',
                    edgecolor=bbox_color,
                    linewidth=1.5 if node == gene_name else 1,
                    alpha=0.9
                ),
                zorder=100
            )
        
        # Edge signatures
        if show_edge_labels and G_vis.number_of_edges() <= 30:
            edge_labels = {(u, v): f"{G_vis[u][v]['weight']:.2f}" 
                          for u, v in G_vis.edges()}
            nx.draw_networkx_edge_labels(
                G_vis, pos,
                edge_labels=edge_labels,
                font_size=7,
                font_color='darkred',
                bbox=dict(facecolor='white', edgecolor='none', alpha=0.7),
                ax=ax
            )
        
        ax.axis('off')
        plt.tight_layout()
        
        return fig


# Comparison of gene regulatory networks between groups
class GRNComparator:
    """
    Comparison of gene regulatory networks between groups.
    """
    
    def __init__(self, model, adata, grn_builder=None):
        """
        Parameters
        ----------
        model: trained scMoses model
        adata: AnnData object
        grn_builder: GRNBuilder (if None, creates new)
        """
        self.model = model
        self.adata = adata
        self.grn_builder = grn_builder or GRNBuilder(model, adata)
    
    def build_condition_specific_grn(self, celltype, condition_key, condition_value,
                                     celltype_key='celltype', **kwargs):
        """
        Constructs a GRN for a subset of cells of a given type and condition
        
        Parameters
        ----------
        celltype: str
            Cell type for analysis from the list of cell types in adata.obs[celltype_key].
        condition_key: str
            column key with condition in adata.obs
        condition_value: str
            The value of the condition (e.g. 'COVID' or 'healthy')
        celltype_key: str
            Cell type key in adata.obs
        **kwargs: additional parameters for function 'build_grn'
        """
        # Data filter
        mask = (self.adata.obs[celltype_key] == celltype) & \
               (self.adata.obs[condition_key] == condition_value)
        
        subset_indices = np.where(mask)[0]
        n_cells = len(subset_indices)

        if n_cells == 0:
            raise ValueError(f"No cells: {celltype} + {condition_value}")
        
        # Create a temporary adata for this subset
        adata_subset = self.adata[subset_indices].copy()
        
        # Temporarily creating a virtual cluster
        adata_subset.obs['_temp_cluster'] = 'target'
        
        # Build GRN
        temp_builder = GRNBuilder(self.model, adata_subset)
        G, edge_data = temp_builder.build_grn(
            cluster_label='target',
            cluster_key='_temp_cluster',
            **kwargs
        )
        
        return G, edge_data, n_cells
    
    def compare_grns(
        self, 
        celltype, 
        condition_key, 
        condition1, 
        condition2,
        celltype_key='celltype', 
        top_genes_count=100,
        **kwargs
    ):
        """
        Compares the GRNs between two conditions.
        
        Parameters
        ----------
        celltype: str
            Cell type for analysis from the list of cell types in adata.obs[celltype_key].
        condition_key: str
            column key with condition in adata.obs.
        condition1: str
            First condition.
        condition2: str
            Second condition.
        celltype_key: str
            Cell type key in adata.obs.
        top_genes_count: int (default: 100)
            Number of genes for GRN construction.
        
        Returns:
            comparison_results: dict
        """
        # Building both networks
        G1, edge_data1, n_cells1 = self.build_condition_specific_grn(
            celltype=celltype, condition_key=condition_key, condition_value=condition1, celltype_key=celltype_key,
            top_genes_count=top_genes_count, **kwargs
        )
        
        G2, edge_data2, n_cells2 = self.build_condition_specific_grn(
            celltype=celltype, condition_key=condition_key, condition_value=condition2, celltype_key=celltype_key,
            top_genes_count=top_genes_count, **kwargs
        )
        
        # Analysis of differences
        results = {
            'G1': G1,
            'G2': G2,
            'edge_data1': edge_data1,
            'edge_data2': edge_data2,
            'condition1': condition1,
            'condition2': condition2,
            'n_cells1': n_cells1,
            'n_cells2': n_cells2,
            'celltype': celltype,
            'celltype_key': celltype_key
        }
        
        # Comparison of nodes
        nodes1 = set(G1.nodes())
        nodes2 = set(G2.nodes())
        
        results['shared_genes'] = nodes1 & nodes2
        results[f'unique_genes_in_{condition1}'] = nodes1 - nodes2
        results[f'unique_genes_in_{condition2}'] = nodes2 - nodes1
        
        # Comparison of edges
        edges1 = set(G1.edges())
        edges2 = set(G2.edges())
        
        results['shared_edges'] = edges1 & edges2
        results[f'unique_edges_{condition1}'] = edges1 - edges2
        results[f'unique_edges_{condition2}'] = edges2 - edges1
        
        # GRNs metrics
        results['metrics1'] = self._compute_network_metrics(G1)
        results['metrics2'] = self._compute_network_metrics(G2)
        
        # Differential hubs
        results['diff_hubs'] = self._identify_differential_hubs(G1, G2, condition1, condition2)
        
        # Differential regulators
        results['diff_regulators'] = self._identify_differential_regulators(
            edge_data1, edge_data2, condition1, condition2
        )
        
        return results
    
    def _compute_network_metrics(self, G):
        """
        Calculates network metrics.
        """
        metrics = {
            'n_nodes': G.number_of_nodes(),
            'n_edges': G.number_of_edges(),
            'density': nx.density(G),
            'avg_degree': np.mean([d for n, d in G.degree()]),
        }
        
        # Calculate the connected components
        try:
            if G.number_of_nodes() > 0:
                metrics['n_components'] = nx.number_weakly_connected_components(G)
                largest_cc = max(nx.weakly_connected_components(G), key=len)
                metrics['largest_component_size'] = len(largest_cc)
        except:
            metrics['n_components'] = 0
            metrics['largest_component_size'] = 0
        
        return metrics
    
    def _identify_differential_hubs(self, G1, G2, condition1, condition2):
        """
        Finds genes with different hub status.
        """
        # Calculate the degree for both networks
        degree1 = dict(G1.degree(weight='weight'))
        degree2 = dict(G2.degree(weight='weight'))
        
        # Все гены
        all_genes = set(degree1.keys()) | set(degree2.keys())
        
        diff_hubs = []
        for gene in all_genes:
            d1 = degree1.get(gene, 0)
            d2 = degree2.get(gene, 0)
            
            diff_hubs.append({
                'gene': gene,
                f'degree_{condition1}': d1,
                f'degree_{condition2}': d2,
                'degree_diff': d1 - d2,
                'fold_change': (d1 + 1) / (d2 + 1)  # псевдосчёт
            })
        
        df = pd.DataFrame(diff_hubs)
        df = df.sort_values('degree_diff', ascending=False, key=abs)
        
        return df
    
    def _identify_differential_regulators(self, edge_data1, edge_data2, condition1, condition2):
        """
        Finds regulators with different number of targets.
        """
        # Calculate the number of targets for each regulator
        reg1 = edge_data1['source'].value_counts().to_dict()
        reg2 = edge_data2['source'].value_counts().to_dict()
        
        all_regs = set(reg1.keys()) | set(reg2.keys())
        
        diff_regs = []
        for reg in all_regs:
            n1 = reg1.get(reg, 0)
            n2 = reg2.get(reg, 0)
            
            diff_regs.append({
                'regulator': reg,
                f'targets_{condition1}': n1,
                f'targets_{condition2}': n2,
                'target_diff': n1 - n2,
                'fold_change': (n1 + 1) / (n2 + 1)
            })
        
        df = pd.DataFrame(diff_regs)
        df = df.sort_values('target_diff', ascending=False, key=abs)
        
        return df
    
    def visualize_comparison(self, results, figsize=(20, 12)):
        """
        Comprehensive visualization of GRN comparison
        """
        fig = plt.figure(figsize=figsize, constrained_layout=True)
        gs = fig.add_gridspec(3, 4)
        
        condition1 = results['condition1']
        condition2 = results['condition2']
        celltype = results['celltype']
        
        # ========== 1. VENN DIAGRAM - Genes ==========
        ax1 = fig.add_subplot(gs[0, :2])
        venn2([results['G1'].nodes(), results['G2'].nodes()],
              set_labels=(condition1, condition2), ax=ax1)
        ax1.set_title('Overlapping Genes', fontsize=12, fontweight='bold')
        
        # ========== 2. VENN DIAGRAM - Edges ==========
        ax2 = fig.add_subplot(gs[0, 2:])
        venn2([set(results['G1'].edges()), set(results['G2'].edges())],
              set_labels=(condition1, condition2), ax=ax2)
        ax2.set_title('Overlapping Edges', fontsize=12, fontweight='bold')
        
        # ========== 3. Top Differential Hubs ==========
        ax3 = fig.add_subplot(gs[1, :2])
        top_diff = results['diff_hubs'].head(15)
        
        colors = ['#FF6B6B' if x > 0 else '#4ECDC4' for x in top_diff['degree_diff']]
        ax3.barh(top_diff['gene'], top_diff['degree_diff'], color=colors)
        ax3.set_xlabel('Degree Difference', fontsize=11)
        ax3.set_title(f'Top Differential Hub Genes ({condition1} - {condition2})', 
                     fontsize=12, fontweight='bold')
        ax3.axvline(0, color='black', linewidth=1)
        ax3.grid(axis='x', alpha=0.3)
        
        # ========== 4. Top Differential Regulators ==========
        ax4 = fig.add_subplot(gs[1, 2:])
        top_regs = results['diff_regulators'].head(15)
        
        colors = ['#FF6B6B' if x > 0 else '#4ECDC4' for x in top_regs['target_diff']]
        ax4.barh(top_regs['regulator'], top_regs['target_diff'], color=colors)
        ax4.set_xlabel('Target Count Difference', fontsize=11)
        ax4.set_title(f'Top Differential Regulators ({condition1} - {condition2})', 
                     fontsize=12, fontweight='bold')
        ax4.axvline(0, color='black', linewidth=1)
        ax4.grid(axis='x', alpha=0.3)
        
        # ========== 5. Degree Distribution Comparison ==========
        ax5 = fig.add_subplot(gs[2, :2])
        
        degrees1 = [d for n, d in results['G1'].degree(weight='weight')]
        degrees2 = [d for n, d in results['G2'].degree(weight='weight')]
        
        ax5.hist(degrees1, bins=20, alpha=0.5, label=condition1, color='#FF6B6B')
        ax5.hist(degrees2, bins=20, alpha=0.5, label=condition2, color='#4ECDC4')
        ax5.set_xlabel('Degree', fontsize=11)
        ax5.set_ylabel('Frequency', fontsize=11)
        ax5.set_title('Degree Distribution', fontsize=12, fontweight='bold')
        ax5.legend()
        ax5.grid(alpha=0.3)
        
        # ========== 6. Edge Weight Comparison ==========
        ax6 = fig.add_subplot(gs[2, 2:])
        
        weights1 = [results['G1'][u][v]['weight'] for u, v in results['G1'].edges()]
        weights2 = [results['G2'][u][v]['weight'] for u, v in results['G2'].edges()]
        
        ax6.hist(weights1, bins=20, alpha=0.5, label=condition1, color='#FF6B6B', log = True)
        ax6.hist(weights2, bins=20, alpha=0.5, label=condition2, color='#4ECDC4', log = True)
        ax6.set_xlabel('Edge Weight', fontsize=11)
        ax6.set_ylabel('Frequency', fontsize=11)
        ax6.set_title('Edge Weight Distribution', fontsize=12, fontweight='bold')
        ax6.legend()
        ax6.grid(alpha=0.3)
        
        return fig
    
    def generate_report(self, results):
        """
        Generates a text report of the difference between conditions.
        """
        condition1 = results['condition1']
        condition2 = results['condition2']
        celltype = results['celltype']
        
        report = f"""
{'='*80}
GENE REGULATORY NETWORK COMPARISON REPORT
{'='*80}

Cell Type: {celltype}
Condition 1: {condition1} ({results['n_cells1']} cells)
Condition 2: {condition2} ({results['n_cells2']} cells)

{'='*80}
NETWORK SIZE COMPARISON
{'='*80}

                        {condition1:>15}    {condition2:>15}    Difference
Nodes (genes)           {results['metrics1']['n_nodes']:>15}    {results['metrics2']['n_nodes']:>15}    {results['metrics1']['n_nodes'] - results['metrics2']['n_nodes']:>10}
Edges (interactions)    {results['metrics1']['n_edges']:>15}    {results['metrics2']['n_edges']:>15}    {results['metrics1']['n_edges'] - results['metrics2']['n_edges']:>10}
Network density         {results['metrics1']['density']:>15.4f}    {results['metrics2']['density']:>15.4f}    {results['metrics1']['density'] - results['metrics2']['density']:>10.4f}
Avg degree              {results['metrics1']['avg_degree']:>15.2f}    {results['metrics2']['avg_degree']:>15.2f}    {results['metrics1']['avg_degree'] - results['metrics2']['avg_degree']:>10.2f}

{'='*80}
GENE OVERLAP
{'='*80}

Shared genes: {len(results['shared_genes'])}
Unique to {condition1}: {len(results[f'unique_genes_in_{condition1}'])}
Unique to {condition2}: {len(results[f'unique_genes_in_{condition2}'])}

{'='*80}
TOP 10 DIFFERENTIAL HUB GENES (by degree difference)
{'='*80}
"""
        top_hubs = results['diff_hubs'].head(10)
        report += top_hubs.to_string(index=False)
        
        report += f"""

{'='*80}
TOP 10 DIFFERENTIAL REGULATORS (by target count difference)
{'='*80}
"""
        top_regs = results['diff_regulators'].head(10)
        report += top_regs.to_string(index=False)
        
        report += f"""

{'='*80}
UNIQUE EDGES TO {condition1.upper()}: {len(results[f'unique_edges_{condition1}'])}
{'='*80}
"""
        if results[f'unique_edges_{condition1}']:
            unique1_sample = list(results[f'unique_edges_{condition1}'])[:20]
            for edge in unique1_sample:
                report += f"{edge[0]} → {edge[1]}\n"
        
        report += f"""
{'='*80}
UNIQUE EDGES TO {condition2.upper()}: {len(results[f'unique_edges_{condition2}'])}
{'='*80}
"""
        if results[f'unique_edges_{condition2}']:
            unique2_sample = list(results[f'unique_edges_{condition2}'])[:20]
            for edge in unique2_sample:
                report += f"{edge[0]} → {edge[1]}\n"
        
        return report


# Enrichment of terms in GRN using gseapy gene_sets
def grn_pathway_enrichment(
    G, 
    gene_sets = [
        'GO_Biological_Process_2025', 
        'Reactome_Pathways_2024', 
        'KEGG_2021_Human'
    ], 
    organism='human',
    top_n = 100,
    cutoff=0.05
):
    """
    Enrichment analysis for genes in GRN

    Parameters
    ----------
    G : networkx or list
        Result of grn_builder.build_grn function
    gene_sets : list
        List of gene sets from gseapy.get_library_name()
    organism : str (default: 'human')
        Organism for calculating enrichment analysis
    top_n : int (default: 100)
        Number of top enriched terms based on a Adjusted P-value
    cutoff : float (default: 0.05)
        Get enriched terms which Adjusted P-value < cutoff.
    """
    # All genes in network
    if isinstance(G, nx.classes.digraph.DiGraph):
        genes_in_network = list(G.nodes())
    elif isinstance(G, list):
        genes_in_network = G
    elif isinstance(G, set):
        genes_in_network = list(G)
    else:
        print('G should be a list, set, or networkx.classes.digraph.DiGraph')

    # Enrichment from gseapy
    enr = gp.enrichr(
        gene_list=genes_in_network,
        gene_sets=gene_sets,
        organism=organism,
        cutoff=cutoff
    )
    
    # Топ обогащенные пути
    top_pathways = enr.results.nsmallest(top_n, 'Adjusted P-value')
    
    return top_pathways
